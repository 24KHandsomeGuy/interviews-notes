package com.gupao.uploader.handler.capitallib.video;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gupao.uploader.constant.EnvProperty;
import com.gupao.uploader.model.ProcessBean;
import com.gupao.uploader.util.FileUtil;
import com.gupao.uploader.util.Md5Util;

@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "SpringJavaAutowiringInspection"})
@Component("capitalLibVideoHandler")
public class CapitalLibVideoHandler extends BaseVideoHandler {

    private static final Logger logger = LoggerFactory.getLogger(CapitalLibVideoHandler.class);

    @Autowired
    private EnvProperty envProperty;

    @Override
    protected void preProcessTitle(ProcessBean processBean) {

        String dir = processBean.getTopDir() +
                processBean.getSectionId() + "/"
                + envProperty.codeVideo + "/";

        if (processBean.getTitle() == null) {
            File file = new File(dir);
            File[] list = file.listFiles(pathname -> pathname.isFile() && pathname.getName().endsWith(".mp4"));

            if (list != null) {
                for (File f : list) {
                    processVideo(f, processBean);
                }
            }
        } else {
            File file = new File(dir + processBean.getTitle() + ".mp4");
            if (file.exists() && file.isFile()) {
                processVideo(file, processBean);
            }
        }
    }

    /**
     * 处理单个视频构建对接数据（含视频截图缩略图）
     * @param file 视频文件
     * @param processBean 预处理结果保存处
     */
    private void processVideo(File file, ProcessBean processBean) {
        ProcessBean.Result result = processBean.getResult();
        // 单个视频
        String absolutePathMp4 = file.getAbsolutePath();

        if (file.exists() && file.isFile() && file.getName().endsWith(".mp4")) {
            String md5;
            try {
                md5 = Md5Util.genQuickMd5(absolutePathMp4);
            } catch (Exception e) {
                logger.error("md5计算出错", e);
                result.processed = result.total;
                return;
            }

            String title = FileUtil.replace(file.getName(), ".mp4", "");
            // 处理封面
            JSONArray array = new JSONArray();
            if (fileUtil.processThumb(absolutePathMp4)) {
                JSONObject record = new JSONObject();
                record.put("fileName", file.getName());
                record.put("title", title);
                record.put("coverPic", title + ".jpg");
                array.add(record);
            }

            JSONObject data = new JSONObject();
            data.put("array", array);
            data.put("baseurl", FileUtil.cutPath(file.getParentFile().getAbsolutePath()));
            data.put("title", title);
            data.put("md5", md5);

            data.put("userId", processBean.getUserId());
            data.put("sectionId", processBean.getSectionId());
            data.put("projectId", processBean.getProjectId());

            // 缓存预发送数据
            savePreProcessData(title, "content/saveVideo", data, processBean.getResult());
        }
    }

    @Override
    public ProcessBean buildProcessBean(String projectId, String sectionId, String userId, String title) {
        ProcessBean processBean = new ProcessBean();
        processBean.setTopDir(String.format(envProperty.video, projectId));

        processBean.setCode(envProperty.codeVideo);
        processBean.setProjectId(projectId);
        processBean.setSectionId(sectionId);
        processBean.setUserId(userId);

        return processBean;
    }
}
