package com.gupao.uploader.model;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.gupao.framework.AuthenticatedUserHolder;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.gupao.uploader.constant.EnvProperty;

/**
 * 文件分片上传
 * Created by mark on 2017/8/20.
 */
public class MultipartFileParam {
    private static final Logger logger = LoggerFactory.getLogger(MultipartFileParam.class);

    private static final String CONTENY_TYPE = "multipart/form-data";
    private static final int CONTENY_TYPE_LEN = CONTENY_TYPE.length();

    private static final String UTF_8 = "UTF-8";

    public void setDir(String dir) {
        this.dir = dir;
    }

    /**
     * 批量分类
     */

    private String code;
    private String projectId;
    private String sectionId;

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    private String userId;
    private String title;

    private String job;
    private String dir;
    private String fileName = null;
    private byte[] bytes;

    private long seekIndex = -1;
    private long chunkEndIndex = -1;
    private long fileSize = -1;

    /**
     * chunk相关参数获取：<br/>
     * 1. 资源类型（视频集、视频、剧集、图书、相册）<br/>
     * 2. 项目ID：projectId<br/>
     * 3. 章节ID：sectionId<br/>
     * 4. 用户ID：userId<br/>
     * 5. 标题：title<br/>
     * 6. chunk起始位置：seekIndex<br/>
     * 7. chunk结束位置：chunkEndIndex<br/>
     * 8. 整个文件大小：totalSize<br/>
     * 9. 文件名称：fileName<br/>
     * 10.文件内容输出流：ByteArrayOutputStream
     * <p>
     * attachment; filename="favicon.png" ---文件名<br/>
     * bytes 0-1023/3312   --- 内容区间<br/>
     * multipart/form-data; boundary=----WebKitFormBoundary8CmyxdsNDd8xdAXP --内容类型<br/>
     *
     *
     * <p/>该方法存在if-else(因为通常类型不需要增加，即便增加，手动增加一个也不太花时间)
     * <p/>如果有洁癖需要去除if-else，可以引入item集合类->类型的映射关系
     * @param request 请求参数
     * @param chunkSizeRule 配置文件中约定的分片大小
     * @throws Exception
     */
    public MultipartFileParam(HttpServletRequest request, int chunkSizeRule, EnvProperty envProperty) throws Exception {

        // 判断头信息：分片上传要求。
        String contentType = request.getHeader("Content-Type");
        if (contentType != null) {
            contentType = contentType.substring(0, CONTENY_TYPE_LEN);
        }
        if (!CONTENY_TYPE.equals(contentType)) {
            throw new RuntimeException(String.format("CONTENY_TYPE is not correct:%s", request.getHeader("Content-Type")));
        }

        // 获取附加参数以及chunk文件流内容
        DiskFileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload sfu = new ServletFileUpload(factory);
        sfu.setHeaderEncoding(UTF_8);
        List<FileItem> items = sfu.parseRequest(request);
        FileItem fileItem = null;
        for (FileItem item : items) {
            if ("code".equals(item.getFieldName())) {
                code = item.getString();

//            } else if ("projectId".equals(item.getFieldName())) {
//                projectId = item.getString();
//
//            } else if ("sectionId".equals(item.getFieldName())) {
//                sectionId = item.getString();
//
//            } else if ("userId".equals(item.getFieldName())) {
//                userId = item.getString();

            } else if ("files".equals(item.getFieldName())) {
                fileItem = item;

            } else if ("title".equals(item.getFieldName())) {
                title = item.getString(UTF_8);

            } else if ("job".equals(item.getFieldName())) {
                job = item.getString(UTF_8);
                HttpSession session = request.getSession(false);
                if (session != null) {
                    User user = (User) session.getAttribute(job);
                    AuthenticatedUserHolder.set(user);
                    sectionId = String.valueOf(user.getSectionID());
                    projectId = String.valueOf(user.getProjectID());
                    userId = String.valueOf(user.getUserID());
                }
            }
        }

        // 非文件上传的请求
        if (fileItem == null) {
            throw new RuntimeException("field [files] not found");
        }

        // 判断chunk文件大小是否合法
        int chunkSize = (int)fileItem.getSize();
        if (chunkSize > chunkSizeRule) {
            RuntimeException e = new RuntimeException(String.format("chunk size:[%s] 超过设定值:%s", chunkSize, chunkSizeRule));
            logger.error(String.format("chunk size:[%s] 超过设定值:%s", chunkSize, chunkSizeRule), e);
            throw e;
        }

        // 保存文件大小(简单处理、因为片不大可以一次性获取)
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buff = new byte[chunkSizeRule];
        int actualCount = fileItem.getInputStream().read(buff, 0, chunkSize);
        baos.write(buff, 0, actualCount);
        baos.flush();
        bytes = baos.toByteArray();
        baos.close();

        // 获取chunk参数值
        resolveContentRange(request);

        // 一次分片都不够的小文件
        if (fileSize == -1) {
            fileName = fileItem.getName();
            fileSize = chunkSize;
            chunkEndIndex = chunkSize-1;
            seekIndex = 0;
        }
        // chunk 存储 dir
        dir = buildDir(envProperty, projectId, code, sectionId, title, fileName);
    }

    /**
     * 获得上传文件存储路径
     */
    public static String buildDir(EnvProperty envProperty, String projectId, String code, String sectionId, String title, String fileName) {

        StringBuilder videoDir = new StringBuilder(String.format(envProperty.video, projectId));

        // 图书chunk dir
        if (envProperty.codeBook.equals(code)) {
            return String.format(envProperty.tmp, projectId);

            // 剧集chunk dir
        } else if (envProperty.codeDramaSeries.equals(code)) {
            return videoDir.append(sectionId).append("/")
                    .append(code).append("/")
                    .append(title).append("/").toString();

            // 视频集 chunk dir
        } else if (envProperty.codeVideos.equals(code)) {
            return videoDir.append(sectionId).append("/")
                    .append(code).append("/")
                    .append(title).append("/").toString();
            
            // 视频 chunk dir
        } else if (envProperty.codeVideo.equals(code)) {
            return videoDir.append(sectionId).append("/")
                    .append(code).append("/").toString();

           // 手机图书 dir
        } else if (envProperty.codePhoneBook.equals(code)) {
            if (fileName.endsWith(".csv")) {
                return String.format(envProperty.tmp, projectId);
            } else {
                return String.format(envProperty.phoneBook, projectId);
            }
        }
        throw new RuntimeException("code 不正确！");
    }

    private void resolveContentRange(HttpServletRequest request) {
        String contentRange = request.getHeader("Content-Range");
        if (!StringUtils.isEmpty(contentRange)) {
            String[] ranges = contentRange.split("[^0-9]+");
            if (ranges.length == 4) {
                seekIndex = Long.parseLong(ranges[1]);
                chunkEndIndex = Long.parseLong(ranges[2]);
                fileSize = Long.parseLong(ranges[3]);
                fileName = getFileName(request);
            }
        }
    }

    /**
     *
     * 根据jquery file uploader(jfu)约定的文件名存放规则，获取文件名
     *
     * <p/>约定：jfu会把文件名放到header头的Content-Disposition里。
     *
     * @param request
     * @return
     */
    private String getFileName(HttpServletRequest request) {
        String contentDisposition = request.getHeader("Content-Disposition");
        if (!StringUtils.isEmpty(contentDisposition)) {
            try {
                contentDisposition = URLDecoder.decode(contentDisposition, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            return contentDisposition.replaceAll("(^[^\"]+\")|(\"$)", "");
        }
        return null;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @return the projectId
     */
    public String getProjectId() {
        return projectId;
    }

    /**
     * @return the sectionId
     */
    public String getSectionId() {
        return sectionId;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return the dir
     */
    public String getDir() {
        return dir;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @return the bytes
     */
    public byte[] getBytes() {
        return bytes;
    }

    /**
     * @return the seekIndex
     */
    public long getSeekIndex() {
        return seekIndex;
    }

    /**
     * @return the chunkEndIndex
     */
    public long getChunkEndIndex() {
        return chunkEndIndex;
    }

    /**
     * @return the fileSize
     */
    public long getFileSize() {
        return fileSize;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}