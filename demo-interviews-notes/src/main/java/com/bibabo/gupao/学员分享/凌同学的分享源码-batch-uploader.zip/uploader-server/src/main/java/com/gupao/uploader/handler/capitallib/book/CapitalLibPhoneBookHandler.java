package com.gupao.uploader.handler.capitallib.book;

import com.alibaba.fastjson.JSONObject;
import com.gupao.uploader.model.ProcessBean;
import com.gupao.uploader.util.FileUtil;
import com.gupao.uploader.util.Md5Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.List;
import java.util.Map;

@Component("capitalLibPhoneBookHandler")
@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "SpringJavaAutowiringInspection"})
public class CapitalLibPhoneBookHandler extends BaseCsvHandler {

    private final  static Logger logger = LoggerFactory.getLogger(CapitalLibPhoneBookHandler.class);

    @Override
    protected void process(List<Map<String, String>> records,
                        String strBookDir,
                        String csvNodeRoot,
                        JSONObject config,
                        ProcessBean processBean) {

        String userId = processBean.getUserId();
        String projectId = processBean.getProjectId();

        ProcessBean.Result result = processBean.getResult();

        // 手机图书文件夹
        File phoneBookDir = new File(strBookDir);
        logger.info("手机图书开始处理...");

        // 开始处理CSV对应的数据
        for (Map<String, String> record : records) {
            result.processed++;

            String bookSn = record.get("图书编号");
            String fileNameQrcode = bookSn + ".png";
            String fileNameThumb = bookSn + ".jpg";

            File thumb = new File(phoneBookDir, fileNameThumb);
            if (!thumb.exists()) {
                fileNameThumb = bookSn + ".jpeg";
                thumb = new File(phoneBookDir, fileNameThumb);
            }
            File qrcode = new File(phoneBookDir, fileNameQrcode);
            if (!qrcode.exists() || !qrcode.isFile()) {
                String msg = String.format("手机图书(%s)二维码图片不存在", fileNameQrcode);
                logger.error(msg);
                result.errMsgs.add(msg);
                continue;
            }
            if (!thumb.exists() || !thumb.isFile()) {
                String msg = String.format("手机图书(%s)缩略图不存在", fileNameThumb);
                logger.error(msg);
                result.errMsgs.add(msg);
                continue;
            }

            result.actual++;

            String md5;
            try {
                String[] files = new String[2];
                files[0] = fileNameThumb;
                files[1] = fileNameQrcode;
                md5 = Md5Util.genQuickMd5(phoneBookDir, files);
            } catch (Exception e) {
                logger.error("md5计算出错", e);
                result.processed = result.total;
                return;
            }
            JSONObject data = new JSONObject();

            data.put("baseurl", FileUtil.cutPath(strBookDir));
            data.put("title", record.get("书名"));
            data.put("authorName", record.get("作者"));
            data.put("sectionId", record.get("分类"));
            data.put("userId", userId);
            data.put("projectId", projectId);
            data.put("md5", md5);
            data.put("publisher", record.get("出版者"));
            data.put("description", record.get("内容简介"));
            data.put("coverPic", fileNameThumb);
            data.put("qrcodePic", fileNameQrcode);
            data.put("bookSn", bookSn);
            data.put("pressDate", record.get("出版日期"));

            String errMsg = apiIface.sendData("content/savePhoneBook", data.toJSONString());
            if (errMsg == null) {
                result.success++;
            } else {
                result.errMsgs.add(errMsg + "\t" + "content/savePhoneBook\t" + data.toJSONString());
            }
        }
    }
}
