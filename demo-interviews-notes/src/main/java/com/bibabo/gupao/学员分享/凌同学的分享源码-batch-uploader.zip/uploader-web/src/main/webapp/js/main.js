$.ajaxSetup({
       xhrFields: {
          withCredentials: true
       }
   });
var url_root = config.url_root + '/uploader-server';

$(function () {
	'use strict';

	// Initialize the jQuery File Upload widget:
	$('#fileupload').fileupload({
		// Uncomment the following to send cross-domain cookies:
		xhrFields: {withCredentials: true}
		// url: 'server/php/'
	});

	// Enable iframe cross-domain access via redirect option:
	$('#fileupload').fileupload(
			'option',
			'redirect',
			window.location.href.replace(
					/\/[^\/]*$/,
					'/cors/result.html?%s'
			)
	);

	// Load existing files:
	$('#fileupload').addClass('fileupload-processing');

	$('#fileupload').fileupload({
		maxChunkSize: 5*1024*1024, // 5 m(不能修改)
		maxRetries: 2, // 失败后重新尝试的次数
		retryTimeout: 500, // 超时响应时间（毫秒）
		messages: {
			existError: '该文件已经存在！',
			typeError: '文件类型与当前批量上传种类不匹配！',
			sectionError: '上传时，分类不能为全部！',
			titleError: '上传剧集时，标题不能为空！',
			acceptFileTypes: '不被允许的文件类型！',
			maxNumberOfFiles: '超过单次处理上限(1000个文件)'
		},
		// 首次(判断之前是否传过：是的话，从起点开始传输)
		add: function (e, data) {
			var that = this;
			var replaceMode= "0";
            if($('#replaceMode').is(':checked')) {
                replaceMode = $("#replaceMode").val();
            }
			var resumeParams = {
            	file: data.files[0].name,
				code:$('input:radio:checked').val(),
				title:$("#title").val(),
				job:$("#job").val(),
				size: data.files[0].size,
                replaceMode: replaceMode
			};
			$.getJSON(url_root + '/web/batchuploader/resuming', resumeParams,
				function (result) {
					var file = result.file;
					data.uploadedBytes = file && file.size;
					if (result.uploadedBytes != 0) {
						data.uploadedBytes = result.uploadedBytes;
					}
					$.blueimp.fileupload.prototype.options.add.call(that, e, data);
			});
		},
		// 失败后（网络问题等等，导致失败的话，重新尝试传输）
		fail: function (e, data) {
			// jQuery Widget Factory uses "namespace-widgetname" since version 1.10.0:
			var fu = $(this).data('blueimp-fileupload') || $(this).data('fileupload'),
			retries = data.context.data('retries') || 0,
			retry = function () {
                var resumeParams = {
                    file: data.files[0].name,
                    code:$('input:radio:checked').val(),
                    title:$("#title").val(),
                    job:$("#job").val(),
                    size: data.files[0].size
                };
				$.getJSON(url_root + '/web/batchuploader/resuming', resumeParams)
				.done(function (result) {
					var file = result.file;
					data.uploadedBytes = file && file.size;
					// clear the previous data:
					if (result.uploadedBytes != 0) {
						data.uploadedBytes = result.uploadedBytes;
					}
					data.data = null;
					data.submit();
				})
				.fail(function () {
					fu._trigger('fail', e, data);
				});
			};
			if (data.errorThrown !== 'abort' &&
					data.uploadedBytes < data.files[0].size &&
					retries < fu.options.maxRetries) {
				retries += 1;
				data.context.data('retries', retries);
				window.setTimeout(retry, retries * fu.options.retryTimeout);
				return;
			}
			data.context.removeData('retries');
			$.blueimp.fileupload.prototype
			.options.fail.call(this, e, data);
		}
	}).on('fileuploadchunksend', function (e, data) {})
    .on('fileuploadchunkdone', function (e, data) {})
    .on('fileuploadchunkfail', function (e, data) {})
    .on('fileuploadchunkalways', function (e, data) {});

	$.ajax({
		// Uncomment the following to send cross-domain cookies:
		//xhrFields: {withCredentials: true},
		url: $('#fileupload').fileupload('option', 'url'),
		dataType: 'json',
		context: $('#fileupload')[0]
	}).always(function () {
		$(this).removeClass('fileupload-processing');
	}).done(function (result) {
		$(this).fileupload('option', 'done')
		.call(this, $.Event('done'), {result: result});
	});
});

$(document).ready(function(){

    var job = GetQueryString("token");
    var sign = GetQueryString("sign");

    if (job == null || sign == null) {
        window.location.href =  "/uploader-web/error.html";
    } else {
        $.ajax({
            type: 'post',
            url: url_root + '/web/user/validateToken',
            data: {job: job, sign: sign, ipAddr:config.ip_address},
            dataType: 'JSON',
            success: function (result) {
                if (result.code == 0) {
                    console.log(result.data.job);

                    if (17 != result.data.projectID) {
                        $("#radio-book").attr("disabled", true);
                        $("#radio-phone-book").attr("disabled", true);
                    }
                    $("#projectName").html(result.data.projectName);
                    $("#sectionName").html(result.data.sectionName);
                    $("#userName").html(result.data.userName);
                    $("#job").val(result.data.job);

                } else if (result.code== 404) {
                    window.location.href = "/uploader-web/error.html";
                } else if (result.code== 403) {
                    window.location.href = "/uploader-web/accesslimit.html";
                } else {
                    window.location.href = "/uploader-web/syserror.html";
                }
            }, fail: function (result) {
                window.location.href = "/uploader-web/syserror.html";
            }, error:function (XMLHttpRequest, textStatus, errorThrown) {
                window.location.href = "/uploader-web/syserror.html";
            }
        });
    }
    $('#fileupload').attr('action', url_root + '/web/batchuploader/upload');

    $('.back-top').unbind().on('click', function() {
    	$(window).scrollTop(0);
    });

    $('#doit').unbind().on('click', function() {
    	 $("#log").css("display", "none");
		 $("#log").attr("href", "");

    	$.ajax({
  	      type: 'post',
  	      url: url_root + '/web/batchuploader/process',
  	      data: {
  	    	  code:$('input:radio:checked').val(),
              job:$("#job").val(),
  	    	  title:$("#title").val()
  	      },
  	      dataType:'JSON',
  	      success: function(result) {
              var $percentbar;
              var $percentprogress;
              var $progress;
              if (result.code == 0) {
                  var token = result.data;

                  $percentbar = $("#bar");
                  $percentprogress = $("#progress");
                  $progress = $(".progress");

                  $progress.css("display", "block");
                  var speed = 500;
                  var mysleep = 0, bar;
                  bar = setInterval(function () {
                      $.ajax({
                          type: 'post',
                          url: url_root + '/web/batchuploader/processStatus',
                          data: {token: token, job:$("#job").val()},
                          async: false,
                          success: function (data) {
                              if (data.code == 0) {
                                  total = data.data.total;
                                  processed = data.data.processed;
                                  total = parseFloat(total);
                                  processed = parseFloat(processed);

                                  percent = total <= 0 ? 0 : (Math.round(processed / total * 10000) / 100.0);

                                  if (processed >= total) {

                                      percent = 100;
                                      $percentbar.css("width", "100%");
                                      $percentprogress.html("100%");
                                      mysleep = mysleep + 1;
                                      if (mysleep >= 4) {
                                          mysleep = 0;
                                          clearInterval(bar);
                                          if (data.data.log) {
                                              $("#log").css("display", "");
                                              $("#log").attr("href", data.data.log);
                                          }

                                          alert("处理完成：" + data.msg);

                                          $progress.css("display", "none");
                                          $percentbar.css("width", "0%");
                                          $percentprogress.html("0%");
                                      }
                                  } else if (data.data.exceptionStatus==true) {
                                      percent = 100;
                                      $percentbar.css("width", "100%");
                                      $percentprogress.html("100%");
                                      mysleep = mysleep + 1;
                                      if (mysleep >= 4) {
                                          mysleep = 0;
                                          clearInterval(bar);

                                          alert("处理过程中产生异常：" + data.data.exceptionMsg);

                                          $progress.css("display", "none");
                                          $percentbar.css("width", "0%");
                                          $percentprogress.html("0%");
                                      }
								  }

                                  $percentbar.css("width", percent + "%");
                                  $percentprogress.html(percent + "%");
                              } else {
                                  clearInterval(bar);
                                  alert('出现错误');
                              }
                          },
                          error: function (e) {
                              clearInterval(bar);
                              alert('服务器出现错误');
                          }
                      });
                  }, speed);
              } else {
                  alert(result.msg);
              }
  	      }
  	  });
    });

    $(":radio").change(function(){

    	$("#clearList").click();

    	$("#title").css('display','');
    	$("#label_title").css('display','');
    	$("#sectionId").css('display','');
    	$("#label_sectionId").css('display','');
    	var val = $('input:radio:checked').val();
    	if (val=='book' || val=='video') {
    		$("#title").css('display','none');
    		$("#label_title").css('display','none');
    		if (val=='book') {
    			$("#sectionId").css('display','none');
    			$("#label_sectionId").css('display','none');
    		}
    	} else if (val=='phoneBook') {
    		$("#title").css('display','none');
    		$("#label_title").css('display','none');
    		$("#sectionId").css('display','none');
			$("#label_sectionId").css('display','none');
    	}
    });

//    $('#logout').unbind().on('click', function() {
//    	 $.ajax({
//             type: 'post',
//             url: url_root + '/user/logout',
//             success: function(data) {
//                 if (data.code == 0 ){
//                     localStorage.userName = '';
//                     window.location.href = 'login.html';
//                 } else {
//                     alert('退出失败');
//                 }
//             }
//         });
//    });
});
window.onscroll = function() {
	if($(window).scrollTop() > 200) {
		$('.back-top').fadeIn();
	} else {
		$('.back-top').fadeOut();
	}
};
