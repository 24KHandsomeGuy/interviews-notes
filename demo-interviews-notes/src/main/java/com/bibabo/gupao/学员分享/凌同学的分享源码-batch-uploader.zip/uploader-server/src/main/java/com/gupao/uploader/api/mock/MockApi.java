package com.gupao.uploader.api.mock;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gupao.uploader.api.ExternApi;
import com.gupao.uploader.constant.EnvProperty;
import com.gupao.uploader.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gupao.uploader.api.ApiIface;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;


public class MockApi implements ApiIface {
    private static final Logger logger = LoggerFactory.getLogger(MockApi.class);

    @Autowired
    private EnvProperty envProperty;

    @Override
    public String sendData(String api, String params) {
        logger.debug(String.format("api=%s, params=%s", api, params));
        return null;
    }

    @Override
    public JSONObject sendData(String api, Map<String, String> data) {
        ExternApi.log(api, data);
        String mock = "{\"code\":\"J000000\",\"data\":{\"sectionID\":56,\"sectionName\":\"北京故事\",\"projectID\":17,\"projectName\":\"首图\",\"userID\":21,\"userName\":\"马建华\"},\"msg\":\"成功\",\"success\":true,\"useReplace\":false}";
        return JSON.parseObject(mock);
    }

    @Override
    public User localLogin() {
        return new User()
                .setProjectID(envProperty.dummyProjectId)
                .setProjectName("dummyPojectName")
                .setSectionID(envProperty.dummySectionId)
                .setSectionName("dummyUserSectionName")
                .setUserID(123456)
                .setUserName("dummyUserName")
                .setIpAddr("http://localhost:8080");
    }
}
