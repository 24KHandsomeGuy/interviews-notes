package com.gupao.framework;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * login中 保持User
 * @author Mark
 *
 */
public class AuthenticatedUserHolder {

	private static final Logger logger = LoggerFactory.getLogger(AuthenticatedUser.class);

	private static final ThreadLocal<AuthenticatedUser> LOGGED_IN_USERS = new ThreadLocal<>();
	
	private AuthenticatedUserHolder(){}
	
	/**
	 * Login中返回User
	 * <p>没有被认证的场合下返回<code>null</code></p>
	 * @return 认证了的用户
	 */
	public static AuthenticatedUser get(){
		return LOGGED_IN_USERS.get();
	}
	
	/**
	 *设置Login中的用户
	 * @param authenticatedUser 被认证过的用户
	 */
	public static void set(AuthenticatedUser authenticatedUser){
		if (authenticatedUser == null) {
			logger.error("authenticatedUser 不能为空");
			throw new RuntimeException("authenticatedUser 不能为空");
		}
		LOGGED_IN_USERS.set(authenticatedUser);
	}
	
	/**
	 * 删除Login用户
	 */
	public static void remove(){
		LOGGED_IN_USERS.remove();
	}
}
