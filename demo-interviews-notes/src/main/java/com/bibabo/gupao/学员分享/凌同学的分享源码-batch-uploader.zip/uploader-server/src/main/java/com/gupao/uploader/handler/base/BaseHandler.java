package com.gupao.uploader.handler.base;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class BaseHandler {
    protected static final ExecutorService fixedThreadPool = Executors.newFixedThreadPool(30);

    public abstract void asyncProcess(Map<String, Object> params) throws Exception;

    @SuppressWarnings("unchecked")
    public <T> T getParam(Map<String, Object> params, String key) {
        Object o = params.get(key);
        return o == null ? null : (T)o;
    }
}
