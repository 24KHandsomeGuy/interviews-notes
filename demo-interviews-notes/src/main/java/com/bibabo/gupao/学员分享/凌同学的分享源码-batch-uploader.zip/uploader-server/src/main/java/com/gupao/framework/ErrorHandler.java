package com.gupao.framework;

import com.alibaba.fastjson.JSONObject;
import com.gupao.framework.anotation.RequestLimitException;
import com.gupao.uploader.constant.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
@RestController
@RequestMapping("/error")
@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "SpringJavaAutowiringInspection"})
public class ErrorHandler {

    private static Logger logger = LoggerFactory.getLogger(ErrorHandler.class);
    @RequestMapping(value = "/handler", produces = Constants.PRODUCES_UTF8)
    public String handler(HttpServletRequest request, HttpServletResponse response) {

        Integer statusCode = (Integer)request.getAttribute("javax.servlet.error.status_code");
        String message = (String)request.getAttribute("javax.servlet.error.message");
        Throwable exception = (Throwable)request.getAttribute("javax.servlet.error.exception");
        String requestUri = (String)request.getAttribute("javax.servlet.error.request_uri");
        response.reset();
        JSONObject data;
        switch (statusCode) {
            case 404:
                data = process404(requestUri);
                break;
            case 400:
                data = process400(requestUri, message);
                break;
            default:
                data = process500(statusCode, exception);
        }
        return log(data);
    }

    private JSONObject process404(String requestUri) {
        JSONObject data = new JSONObject();
        data.put("code", 404);
        data.put("msg", String.format("资源[%s]不存在!", requestUri));
        return data;
    }

    private JSONObject process400(String requestUri, String message) {
        JSONObject data = new JSONObject();
        data.put("code", 400);
        String msg = requestUri + ":" + message;
        data.put("msg", msg);
        return data;
    }

    private JSONObject process500(Integer statusCode, Throwable exception) {
        JSONObject data = new JSONObject();
        data.put("code", statusCode);
        // 业务异常
        try {
            throw exception.getCause();
        } catch (RequestLimitException rle) {
            data.put("code", 403);
            data.put("msg", "访问过于频繁，禁止访问！");
        } catch (BaseException be) {
            data.put("msg", "系统业务异常");
        } catch (Throwable t) {
            t.printStackTrace();
            data.put("msg", "系统异常");
        }
        return data;
    }

    private String log(JSONObject data) {
        String error = data.toJSONString();
        logger.error(error);
        return error;
    }
}
