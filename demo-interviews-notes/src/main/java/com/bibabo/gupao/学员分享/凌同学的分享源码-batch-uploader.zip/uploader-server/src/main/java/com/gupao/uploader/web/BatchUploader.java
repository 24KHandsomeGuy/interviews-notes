package com.gupao.uploader.web;


import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import com.gupao.framework.AuthenticatedUserHolder;
import com.gupao.uploader.model.User;
import com.gupao.framework.JsonConfig;
import com.gupao.uploader.handler.base.BaseHandler;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.gupao.framework.UploadProcessHolder;
import com.gupao.uploader.constant.Constants;
import com.gupao.uploader.constant.EnvProperty;
import com.gupao.uploader.model.MultipartFileParam;
import com.gupao.uploader.model.ProcessBean;
import com.gupao.uploader.util.FileUtil;
import com.gupao.uploader.util.ChunkUtil;
import com.gupao.uploader.util.FastJsonUtil;

@Component("uploader")
@RestController
@RequestMapping(value="/web/batchuploader")
@SuppressWarnings("SpringAutowiredFieldsWarningInspection")
public class BatchUploader {

    private final  static Logger logger = LoggerFactory.getLogger(BatchUploader.class);

    @Autowired
    private FileUtil fileUtil;

    @Autowired
    private EnvProperty envProperty;

    @Autowired
    private ChunkUtil chunkUtil;

    @Autowired
    private JsonConfig jsonConfig;

    /**
     * 上传chunk
     * @param request 请求
     * @return json
     * @throws Exception 参数解析异常
     */
    @RequestMapping(value="/upload", method = {RequestMethod.POST}, produces = Constants.PRODUCES_UTF8)
    public String upload(HttpServletRequest request) throws Exception {

        // 解析参数
        MultipartFileParam params = new MultipartFileParam(request, envProperty.CHUNK_SIZE, envProperty);

        String fileName = params.getFileName();
        String code = params.getCode();
        String projectId = params.getProjectId();

        // 图书类的配置文件特殊命名
        if (fileName.endsWith(".csv")) {
            params.setFileName(code + ".csv");
        }

        // 存储chunk
        boolean done = chunkUtil.saveChunk(params);
        String dir = params.getDir();

        // 如果是zip文件需要解压到对应的book目录
        if (done) {
            logger.info(fileName + " was successfully uploaded.");
            if (fileName.endsWith(".zip")) {
                fileUtil.decompressZip(dir + fileName, String.format(envProperty.book, projectId));
            } else if (fileName.endsWith(".mp4")) {
                fileUtil.processThumb(dir + fileName);
            }
        }

        // 前端显示用结果
        return chunkUtil.result(params.getFileName(), params.getFileSize(), dir).toJSONString();
    }

    /**
     * 上传chunk
     * @param token 处理进度检查令牌
     * @return json
     */
    @RequestMapping(value="/processStatus", produces = Constants.PRODUCES_UTF8)
    public String processStatus(@RequestParam(value = "token") String token) {
        ProcessBean processBean  = UploadProcessHolder.holder().get(token);
        ProcessBean.Result result = processBean.getResult();

        JSONObject data = new JSONObject();
        data.put("total", result.total);
        data.put("actual", result.actual);
        data.put("processed", result.processed);
        data.put("success", result.success);
        data.put("exceptionStatus", result.exceptionStatus);
        data.put("exceptionMsg", result.exceptionMsg);

        String msg = data.toJSONString();
        if (processBean.getResult().total > 0
              && processBean.getResult().processed >= processBean.getResult().total) {
            String logPath = processBean.getResult().writeLog(token, String.format(envProperty.tmp, processBean.getProjectId()));
            if (logPath != null) {
                User user = (User)AuthenticatedUserHolder.get();
                String accessDomain = user.getIpAddr();
                if (!accessDomain.endsWith("/")) {
                    accessDomain +="/";
                }
                data.put("log", FileUtil.replace(logPath, envProperty.envTopdir, accessDomain, Boolean.FALSE));
            }
        }
        return FastJsonUtil.success(msg, data).toJSONString();
    }

    @RequestMapping(value="/process", method = { RequestMethod.POST }, produces = Constants.PRODUCES_UTF8)
    public String process(@RequestParam(value = "code") String code,
            @RequestParam(value = "title", required=false) String title) throws Exception {
        User user = (User)AuthenticatedUserHolder.get();
        String sectionId = String.valueOf(user.getSectionID());
        String projectId = String.valueOf(user.getProjectID());
        String userId = String.valueOf(user.getUserID());

        if (StringUtils.isEmpty(sectionId)) {
            sectionId = "all";
        }
        if (StringUtils.isEmpty(title) ) {
            title = null;
        }
        String token = UUID.randomUUID().toString();

        Map<String, Object> params = new HashMap<>();
        params.put("projectId", projectId);
        params.put("sectionId", sectionId);
        params.put("userId", userId);
        params.put("title", title);
        params.put("token", token);
        params.put("code", code);

        BaseHandler baseHandler = jsonConfig.getProcHandler(projectId, code);

        // 异步处理
        baseHandler.asyncProcess(params);

        return FastJsonUtil.success("success", token).toJSONString();
    }

   /**
    * 断点续传试探API
    * @param fileName 文件名
    * @param code 类型
    * @param title 标题
    * @return {file:{size:xxx}}
    */
    @RequestMapping(value = "/resuming", produces = Constants.PRODUCES_UTF8)
    public String resuming(
            @RequestParam(value = "file") String fileName,
            @RequestParam(value = "code") String code,
            @RequestParam(value = "title") String title,
            @RequestParam(value = "replaceMode", required = false, defaultValue ="0") String replaceMode) {

        User user = (User)AuthenticatedUserHolder.get();
        String sectionId = String.valueOf(user.getSectionID());
        String projectId = String.valueOf(user.getProjectID());
        String dir = MultipartFileParam.buildDir(envProperty, projectId, code, sectionId, title, fileName);

        // 图书类的配置文件特殊命名
        if (fileName.endsWith(".csv")) {
            fileName = code + ".csv";
        }
        int uploadedBytes = checkFileType(fileName, code, sectionId, title);
        if (uploadedBytes == 0) {
            FileUtil.createLocalFolder(dir);
        }

        long fileSize = 0;
        File file = new File(dir, fileName);

        if (file.exists() && file.isFile()) {
            if ("1".equals(replaceMode)) {
                FileUtils.deleteQuietly(file);
            } else {
                fileSize = file.length();
            }
        }
        JSONObject result = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("size", fileSize);
        result.put("file", data);
        result.put("uploadedBytes", uploadedBytes);
        return result.toJSONString();
    }

    /**
     * 检查批量上传类型和选择的文件类型是否匹配
     * @param fileName 文件名称
     * @param code 批量上传类型
     * @param sectionId 章节ID
     * @param title 标题ID
     * @return 相应的错误码 (-1, 0,-2,-3);其中0位合法，其余为不正常。
     */
    private int checkFileType(String fileName, String code, String sectionId, String title) {
        int msg = -1;
        if (envProperty.codeBook.equals(code)) {
            if (fileName.matches(".*\\.(csv|zip)")) {
                msg = 0;
            }
            if (sectionId == null || "all".equals(sectionId)) {
                msg = -2;
            }
        } else if (envProperty.codePhoneBook.equals(code)) {
            if (fileName.matches(".*\\.(csv|jpe?g|png)")) {
                msg = 0;
            }
        } else if (envProperty.codeDramaSeries.equals(code)) {
            if (fileName.matches(".*\\.(mp4)")) {
                msg = 0;
            }
            if (sectionId == null || "all".equals(sectionId)) {
                msg = -2;
            } else if (title == null || title.trim().isEmpty()) {
                msg = -3;
            }

        } else if (envProperty.codeVideo.equals(code)) {
            if (fileName.matches(".*\\.(mp4)")) {
                msg = 0;
            }
            if (sectionId == null || "all".equals(sectionId)) {
                msg = -2;
            }
        }
        return msg;
    }
}
