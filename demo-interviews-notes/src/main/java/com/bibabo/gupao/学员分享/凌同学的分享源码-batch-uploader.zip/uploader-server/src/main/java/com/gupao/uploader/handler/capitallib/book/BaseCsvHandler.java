package com.gupao.uploader.handler.capitallib.book;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.csvreader.CsvReader;
import com.gupao.framework.UploadProcessHolder;
import com.gupao.uploader.api.ApiIface;
import com.gupao.uploader.constant.EnvProperty;
import com.gupao.uploader.handler.base.BaseHandler;
import com.gupao.uploader.model.ProcessBean;
import com.gupao.framework.JsonConfig;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * 图书类处理基类
 *
 * @author mark@gupao.com
 */
@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "WeakerAccess", "SpringJavaAutowiringInspection"})
public abstract class BaseCsvHandler extends BaseHandler {
    private final  static Logger logger = LoggerFactory.getLogger(BaseCsvHandler.class);

    /**
     * 外部接口类
     */
    @Autowired
    protected ApiIface apiIface;
    /**
     * 配置类
     */
    @Autowired
    protected JsonConfig jsonConfig;

    @Autowired
    private EnvProperty envProperty;

    /**
     * 图书类异步处理
     * @param params Map参数<br/>
     * ------------------------<br/>
     * projectId 项目Id
     * token 生成的查询token
     * userId 用户ID
     * csvNodeName procHandler的节点
     */
    @Override
    public void asyncProcess(Map<String, Object> params) throws Exception {
        String projectId = getParam(params, "projectId");
        String token = getParam(params, "token");
        String userId = getParam(params, "userId");
        String code = getParam(params, "code");

        final BaseCsvHandler bookHandler = jsonConfig.getProcHandler(projectId, code);

        final ProcessBean processBean = new ProcessBean();
        processBean.setUserId(userId);
        processBean.setProjectId(projectId);

        UploadProcessHolder.holder().put(token, processBean);

        fixedThreadPool.execute(() -> {
            try {
                bookHandler.process(code,
                        String.format(envProperty.tmp, projectId) + code + ".csv",
                        envProperty.batchUpload + projectId + "/" + code + "/",
                        processBean);
            } catch (Exception e) {
                logger.error("处理过程产生异常", e);

                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);
                e.printStackTrace(pw);
                ProcessBean.Result result = processBean.getResult();
                result.exceptionMsg = sw.toString();
                result.exceptionStatus = Boolean.TRUE;
            }
        });
    }

    /**
     * 获取csv节点
     * @param config 项目根节点
     * @param csvNodeRoot csv节点名称
     * @return 返回csv节点相应的JsonObject
     */
    protected JSONObject getCsvNode(JSONObject config, String csvNodeRoot) {
        // 获取project根
        JSONObject project = config.getJSONObject("project");

        // 获取csvNode
        return project.getJSONObject(csvNodeRoot);
    }

    protected List<String> getCsvConfigHeaders(JSONObject config, String csvNodeRoot) {

        // csvNode
        JSONObject csvNode = getCsvNode(config, csvNodeRoot);

        // 获取csv
        JSONObject csv = csvNode.getJSONObject("csv");

        // 获取csv配置头信息
        JSONArray csvFields = csv.getJSONArray("fields");

        List<String> csvHeaders = new ArrayList<>();
        for (int i = 0; i < csvFields.size(); i++) {
            JSONObject cscField = csvFields.getJSONObject(i);

            String name = cscField.getString("field");
            csvHeaders.add(name);
        }
        return csvHeaders;
    }

    /**
     * 获取对应的转换器
     * @param config json根配置
     * @param csvNodeRoot csvRoot名称
     * @return 转换器Map
     */
    protected Map<String, Map<String, String>> getConverts(JSONObject config, String csvNodeRoot) {
        // 获取csvNode
        JSONObject csvNode = getCsvNode(config, csvNodeRoot);

        // 获取csv
        JSONObject csv = csvNode.getJSONObject("csv");

        JSONArray fields = csv.getJSONArray("fields");

        Map<String, Map<String, String>> converters = new HashMap<>();
        for (int i = 0; i < fields.size(); i++) {
            JSONObject field = fields.getJSONObject(i);
            if (field.containsKey("converter")) {
                JSONArray converter = field.getJSONArray("converter");
                Map<String, String> converterField = new HashMap<>();
                for (int j = 0; j < converter.size(); j++ ) {
                    JSONObject node = converter.getJSONObject(j);
                    String name = node.getString("name");
                    String code = node.getString("code");
                    converterField.put(name, code);
                }
                String fieldName = field.getString("field");
                converters.put(fieldName, converterField);
            }
        }
        return converters;
    }

    /**
     * 使用converter转换分类名称->code
     * @param record csv一条记录
     * @param converters csvConfig中的转化器
     */
    protected void convertRecord(Map<String, String> record, Map<String, Map<String, String>> converters) {
        Set<Map.Entry<String, Map<String, String>>> set = converters.entrySet();

        for (Map.Entry<String, Map<String, String>> entry : set) {
            String key = entry.getKey();
            String oldValue = record.get(key);
            Map<String, String> converter = entry.getValue();
            record.put(key, converter.get(oldValue));
        }
    }

    /**
     * 需要根据业务覆盖实现的处理方法。
     * @param records csv文件中的记录列表(名称->Code已经转换完毕)
     * @param strBookDir 上传后的book文件夹(绝对地址)
     * @param csvNodeRoot json文件中的csvNodeRoot节点名称
     * @param config 该项目的json配置信息
     * @param processBean 结果查询bean（其中userId和projectId为必须属性）
     */
    protected abstract void process(List<Map<String, String>> records,
                                    String strBookDir,
                                    String csvNodeRoot,
                                    JSONObject config,
                                    ProcessBean processBean);

    /**
     * 控制器接收请求后的中央控制器（通用的核心逻辑）
     * @param csvNodeRoot json文件中的csvNodeRoot节点名称
     * @param csvPath csv文件的绝对地址
     * @param strBookDir 图书文件夹的绝对地址
     * @param processBean 结果查询bean（其中userId和projectId为必须属性）
     * @throws Exception 处理过程中产生的异常信息
     */
    public void process(String csvNodeRoot,
                        String csvPath,
                        String strBookDir,
                        ProcessBean processBean) throws Exception {
        String projectId = processBean.getProjectId();
        // 获取配置信息
        JSONObject config = jsonConfig.read(projectId);

        // 获取相应的Spring实例Bean
        BaseCsvHandler baseCsvHandler = jsonConfig.getProcHandler(config, csvNodeRoot);

        // 获取配置文件中csv头信息
        List<String> configHeaders = baseCsvHandler.getCsvConfigHeaders(config, csvNodeRoot);

        // 获取CSV文件头
        Set<String> csvHeaders = this.loadCsvFileHeader(csvPath);

        // 验证配置文件中csv头信息和上传的csv文件头信息
        this.validateHeaders(configHeaders, csvHeaders);

        // 获取csv文件内容
        csvPath = String.format(csvPath, projectId);
        List<Map<String, String>> records = this.loadCsvFile(csvPath, configHeaders);

        // 静默删除Csv文件
        FileUtils.deleteQuietly(new File(csvPath));

        // 获取相应的转换器
        Map<String, Map<String, String>> converters = getConverts(config, csvNodeRoot);

        // 使用转换器对csv内容进行转义(名称 -> CODE)
        for (Map<String, String> record : records) {
            // 转换名称 -> code值
            convertRecord(record, converters);
        }

        // 设置初始值 csv中记录总数
        processBean.getResult().total = records.size();
        processBean.getResult().actual = 0;
        processBean.getResult().processed = 0;

        process(records, String.format(strBookDir, projectId), csvNodeRoot, config, processBean);
    }

    /**
     * 获取文件内容
     * @param csvPath csv文件
     * @param configHeaders csv文件头中必要的信息
     * @return csv内容列表
     * @throws Exception 获取文件内容出错时，产生异常
     */
    private List<Map<String, String>> loadCsvFile(String csvPath, List<String> configHeaders) throws Exception {
        CsvReader csvReader = null;
        List<Map<String, String>> records = new ArrayList<>();
        try {
            csvReader = new CsvReader(csvPath, ',', Charset.forName("UTF-8"));
            if (!csvReader.readHeaders()) {
                String msg = String.format("获取CSV文件头出错. loadCsvFile(%s)出错:", csvPath);
                RuntimeException e = new RuntimeException("");
                logger.error(msg, e);
                throw e;
            }

            // 跳过csv文件中的空行
            csvReader.setSkipEmptyRecords(true);
            while (csvReader.readRecord()) {
                Map<String, String> record = new HashMap<>();
                for (String header : configHeaders) {
                    String content = csvReader.get(header);
                    record.put(header, content);
                }
                records.add(record);
            }
        } catch (Exception e) {
            logger.error(String.format("获取文件内容出错. loadCsvFile(%s)出错:", csvPath), e);
            throw e;
        } finally {
            if (csvReader != null) {
                csvReader.close();
            }
        }
        return records;
    }

    /**
     * 验证CSV头信息是否正确
     * @param configHeaders 配置文件中CSV头信息
     * @param csvHeaders csv文件中头信息
     */
    private void validateHeaders(List<String> configHeaders, Set<String> csvHeaders) {
        for (String header : configHeaders) {
            if (!csvHeaders.contains(header)) {
                String msg = String.format("json配置文件中的Header(%s)，在csv文件中不存在", header);
                RuntimeException e = new RuntimeException(msg);
                logger.error(msg, e);
                throw e;
            }
        }
    }

    /**
     * 获取CSV文件头信息
     * @param csvFile csv文件
     * @return CSV文件头(Set集合)
     * @throws Exception 获取文件头出错时，产生异常
     */
    private Set<String> loadCsvFileHeader(String csvFile) throws Exception {
        CsvReader csvReader = null;
        Set<String> headers = new HashSet<>();
        try {
            csvReader = new CsvReader(csvFile, ',', Charset.forName("UTF-8"));
            csvReader.readHeaders();
            int columnCount = csvReader.getHeaderCount();
            for (int i = 0; i < columnCount; i++) {
                headers.add(csvReader.getHeader(i));
            }
        } catch (Exception e) {
            logger.error(String.format("获取csvHeader(%s)出错:", csvFile), e);
            throw e;
        } finally {
            if (csvReader != null) {
                csvReader.close();
            }
        }
        return headers;
    }
}
