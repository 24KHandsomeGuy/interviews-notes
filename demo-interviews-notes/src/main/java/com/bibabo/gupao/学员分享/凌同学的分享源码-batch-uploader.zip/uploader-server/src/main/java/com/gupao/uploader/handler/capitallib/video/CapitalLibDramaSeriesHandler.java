package com.gupao.uploader.handler.capitallib.video;

import java.io.File;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gupao.uploader.constant.EnvProperty;
import com.gupao.uploader.model.ProcessBean;
import com.gupao.uploader.util.FileUtil;
import com.gupao.uploader.util.Md5Util;

@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "SpringJavaAutowiringInspection"})
@Component("capitalLibDramaSeriesHandler")
public class CapitalLibDramaSeriesHandler extends BaseVideoHandler {

    private static final Logger logger = LoggerFactory.getLogger(CapitalLibDramaSeriesHandler.class);
    @Autowired
    private EnvProperty envProperty;

    @Override
    protected void preProcessTitle(ProcessBean processBean) {
        ProcessBean.Result result = processBean.getResult();

        // 剧集文件夹
        String dir = processBean.getTopDir() +
                processBean.getSectionId() +  "/"
                + envProperty.codeDramaSeries +  "/"
                + processBean.getTitle();

        File file = new File(dir);
        if (!file.exists() || !file.isDirectory()) {
            result.processed = result.total;
            return;
        }

        String[] files = file.list((dir1, name) -> name.matches(".*\\.(mp4)"));

        if (files != null && files.length != 0) {
            JSONArray array = new JSONArray();
            array.addAll(Arrays.asList(files));
            String md5;
            try {
                md5 = Md5Util.genQuickMd5(file, files);
            } catch (Exception e) {
                logger.error("md5计算出错", e);
                result.processed = result.total;
                result.actual = 0;
                return;
            }

            JSONObject data = new JSONObject();
            data.put("array", array);
            data.put("baseurl", FileUtil.cutPath(dir));
            String title = processBean.getTitle();
            data.put("title", processBean.getTitle());
            data.put("md5", md5);

            data.put("userId", processBean.getUserId());
            data.put("sectionId", processBean.getSectionId());
            data.put("projectId", processBean.getProjectId());

            // 缓存预发送数据
            savePreProcessData(title, "content/saveDramaSeries", data, processBean.getResult());
         }
    }

    @Override
    public ProcessBean buildProcessBean(String projectId, String sectionId, String userId, String title) {
        ProcessBean processBean = new ProcessBean();
        processBean.setTopDir(String.format(envProperty.video, projectId));
        processBean.setCode(envProperty.codeDramaSeries);
        processBean.setProjectId(projectId);
        processBean.setSectionId(sectionId);
        processBean.setUserId(userId);
        processBean.setTitle(title);

        return processBean;
    }
}
