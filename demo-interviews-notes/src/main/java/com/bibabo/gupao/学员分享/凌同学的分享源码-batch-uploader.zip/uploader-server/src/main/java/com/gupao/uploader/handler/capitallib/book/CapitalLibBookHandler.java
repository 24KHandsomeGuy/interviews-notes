package com.gupao.uploader.handler.capitallib.book;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gupao.uploader.model.ProcessBean;
import com.gupao.uploader.util.FileUtil;
import com.gupao.uploader.util.Md5Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Component("capitalLibBookHandler")
@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "SpringJavaAutowiringInspection"})
public class CapitalLibBookHandler extends BaseCsvHandler {

    private final  static Logger logger = LoggerFactory.getLogger(CapitalLibBookHandler.class);

    public CapitalLibBookHandler() {
        System.out.println("CapitalLibBookHandler 被初始化。。。");   
    }
    /**
     * 获取book中jpg的上层dir
     * @param picPath 图书jpg的相对路径
     * @return 图书jpg的上层dir
     */
    private String getPicDir(String picPath) {
        if (picPath == null) {
            return null;
        }
        int index = picPath.lastIndexOf("/");
        return index > 0 ?picPath.substring(0, index) : picPath;
    }

    @Override
    protected void process(List<Map<String, String>> records,
                        String strBookDir,
                        String csvNodeRoot,
                        JSONObject config,
                        ProcessBean processBean) {

        String userId = processBean.getUserId();
        String projectId = processBean.getProjectId();

        ProcessBean.Result result = processBean.getResult();

        // 开始处理CSV对应的数据
        for (Map<String, String> record : records) {

            // 获取jpg的相对Dir路径
            String picDir = getPicDir(record.get("图像路径"));

            // jpg dir的绝对路径
            String absoluteDir = strBookDir + picDir;
            File file = new File(absoluteDir);

            // 该文件夹下只有jpe?g和png是目标文件
            String[] files = file.list((dir, name) -> name.matches(".*\\.(jpe?g|png)"));

            // 有图像文件时，开始处理
            if (files != null && files.length != 0) {
                // 有相应的图书时，图书实际计数器+1
                result.actual++;

                // 日志：记录开始处理
                logger.info(picDir + " 开始处理");

                // 该文件夹下所有jpe?g和png都是目标对象，作为array数组值
                JSONArray array = new JSONArray();
                array.addAll(Arrays.asList(files));

                // 快速计算该文件夹下所有目标的Md5值
                String md5;
                try {
                    md5 = Md5Util.genQuickMd5(file, files);
                } catch (Exception e) {
                    logger.error("md5计算出错", e);
                    result.processed = result.total;
                    return;
                }

                JSONObject data = new JSONObject();
                data.put("array", array);

                data.put("baseurl", FileUtil.cutPath(absoluteDir));
                data.put("title", record.get("书名"));
                data.put("authorName", record.get("作者"));
                data.put("pressDate", record.get("出版日期"));
                data.put("publisher", record.get("出版社"));
                data.put("totlePage", record.get("页数"));
                data.put("libName", record.get("图书馆代码"));
                data.put("md5", md5);

                data.put("userId", userId);
                data.put("sectionId", record.get("图书馆代码"));

                // 项目Id
                data.put("projectId", projectId);
                String errMsg = apiIface.sendData("content/saveBook", data.toJSONString());
                if (errMsg == null) {
                    result.success++;
                } else {
                    result.errMsgs.add(errMsg + "\t" + "content/saveBook\t" + data.toJSONString());
                }
            }
            result.processed++;
        }
    }
}
