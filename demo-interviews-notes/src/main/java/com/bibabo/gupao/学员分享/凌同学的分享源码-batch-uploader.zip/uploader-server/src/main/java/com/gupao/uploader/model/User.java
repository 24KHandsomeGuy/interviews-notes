package com.gupao.uploader.model;

import com.gupao.framework.AuthenticatedUser;

import java.io.Serializable;


/**
 *
 * 认证的用户信息类
 * @author Mark
 *
 */
public class User implements AuthenticatedUser, Serializable {

	private static final long serialVersionUID = 1L;

	/** 项目ID */
	private Integer projectID;

	private String ipAddr;

    public String getIpAddr() {
        return ipAddr;
    }

    public User setIpAddr(String ipAddr) {
        this.ipAddr = ipAddr;
        return this;
    }

    @Override
    public String toString() {
        return "User{" +
                "projectID=" + projectID +
                ", projectName='" + projectName + '\'' +
                ", sectionID=" + sectionID +
                ", sectionName='" + sectionName + '\'' +
                ", userID=" + userID +
                ", userName='" + userName + '\'' +
                '}';
    }

    private String projectName;
    /** 章节ID */

    private Integer sectionID;

    public Integer getProjectID() {
        return projectID;
    }

    public User setProjectID(Integer projectID) {
        this.projectID = projectID;
        return this;
    }

    public String getProjectName() {
        return projectName;
    }

    public User setProjectName(String projectName) {
        this.projectName = projectName;
        return this;
    }

    public Integer getSectionID() {
        return sectionID;
    }

    public User setSectionID(Integer sectionID) {
        this.sectionID = sectionID;
        return this;
    }

    public String getSectionName() {
        return sectionName;
    }

    public User setSectionName(String sectionName) {
        this.sectionName = sectionName;
        return this;
    }

    public Integer getUserID() {
        return userID;
    }

    public User setUserID(Integer userID) {
        this.userID = userID;
        return this;
    }

    public String getUserName() {
        return userName;
    }

    public User setUserName(String userName) {
        this.userName = userName;
        return this;
    }

    private String sectionName;

    /** userID */
    private Integer userID;
    private String userName;


}
