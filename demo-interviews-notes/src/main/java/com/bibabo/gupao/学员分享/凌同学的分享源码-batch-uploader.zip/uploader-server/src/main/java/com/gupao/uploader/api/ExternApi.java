package com.gupao.uploader.api;

import java.util.HashMap;
import java.util.Map;

import com.gupao.uploader.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.github.kevinsawicki.http.HttpRequest;
import com.gupao.uploader.constant.Constants;
import com.gupao.uploader.constant.EnvProperty;

@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "SpringJavaAutowiredMembersInspection"})
public class ExternApi implements ApiIface {

    private static final Logger logger = LoggerFactory.getLogger(ExternApi.class);

    @Autowired
    private EnvProperty envProperty;

    @Override
    public String sendData(String api, String params) {
        try {
            logger.debug(String.format("api=%s, params=%s", api, params));
            Map<String, String> data = new HashMap<>();
            data.put("params", params);
            HttpRequest request = HttpRequest.post(envProperty.gehuaSystemApiDomain + api).form(data);

            if (request.code() != 200) {
                String errMsg = String.format("对接系统状态码出错:%s", request.code());
                logger.error(errMsg);
                return errMsg;
            }

            String body = request.body();
            logger.info(String.format("系统对接响应结果：%s", body));
            JSONObject jsonResult = JSONObject.parseObject(body);
            String retCode = jsonResult.getString("code");
            if (Constants.API_SUCCESS_CODE.equals(retCode)) {
                return null;
            }
            return body;

        } catch (Exception e) {
            String errMsg = "对接系统出错误";
            logger.error(errMsg, e);
            return errMsg;
        }
    }

    public static void log(String api, Map<String, String> data) {
        if (logger.isDebugEnabled()) {
            StringBuilder params = new StringBuilder("api=" + api);
            for (Map.Entry<String, String> entry : data.entrySet()) {
                params.append(",")
                        .append(entry.getKey())
                        .append("=")
                        .append(entry.getValue());
            }
            logger.debug(params.toString());
        }
    }

    @Override
    public JSONObject sendData(String api, Map<String, String> data) {
        try {
            log(api, data);
            HttpRequest request = HttpRequest.post(envProperty.gehuaSystemApiDomain + api).form(data);

            if (request.code() != 200) {
                logger.error(String.format("对接系统状态码出错:%s", request.code()));
                return null;
            }

            String body = request.body();
            logger.info(String.format("系统对接响应结果：%s", body));
            JSONObject jsonResult = JSONObject.parseObject(body);
            String retCode = jsonResult.getString("code");
            if (!Constants.API_SUCCESS_CODE.equals(retCode)) {
                return null;
            }
            return jsonResult;

        } catch (Exception e) {
            logger.error("对接系统出错误", e);
            return null;
        }
    }

    @Override
    public User localLogin() {
        return null;
    }
}
