package com.gupao.framework;

import com.gupao.uploader.model.ProcessBean;

/**
 * 上传进度 Holder
 * @author majianhua
 *
 */
public class UploadProcessHolder {
    private static final int DEFAULT_INITIAL_CAPACITY = 16;
    private static final float DEFAULT_LOAD_FACTOR = 0.75f;
    private static final int DEFAULT_CACHE_SIZE = 256;

    private final LRUCache<String, ProcessBean> processCache =
            new LRUCache<>(DEFAULT_INITIAL_CAPACITY, DEFAULT_LOAD_FACTOR, DEFAULT_CACHE_SIZE);

    /**
     * 构造方法私有化
     */
    private UploadProcessHolder(){}

    /**
     * 懒加载单例.
     * @author majianhua
     *
     */
    private static class HelperHolder {
        private static final UploadProcessHolder INSTANCE = new UploadProcessHolder();
    }

    /**
     * Singleton instance
     * @return
     */
    public static UploadProcessHolder holder() {
        return HelperHolder.INSTANCE;
    }

    public ProcessBean get(String key) {
        return processCache.get(key);
    }
    public ProcessBean put(String key, ProcessBean processBean) {
        return processCache.put(key, processBean);
    }

}
