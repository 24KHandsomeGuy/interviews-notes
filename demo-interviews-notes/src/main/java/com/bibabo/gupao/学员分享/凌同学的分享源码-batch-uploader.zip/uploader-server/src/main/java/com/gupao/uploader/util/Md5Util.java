package com.gupao.uploader.util;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * MD5计算工具类
 * @author mark
 */
public class Md5Util {
    private static final Logger logger = LoggerFactory.getLogger(Md5Util.class);
    private Md5Util(){
    }

    /**
     * 计算文件夹下文件列表内的文件Md5和值<br/>
     * 
     * 基于性能考虑：计算素材选取为文件名称+文件长度
     * @param parentFile 文件夹
     * @param files 文件名称列表
     * @return Md5结果字符串
     * @throws IOException 文件不存在异常
     * @throws NoSuchAlgorithmException 计算MD5异常
     */
    public static String genQuickMd5(File parentFile, String[] files) throws IOException, NoSuchAlgorithmException {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        for (String file : files) {
            File f = new File(parentFile, file);
            InputStream ins = new FileInputStream(f);
            byte[] buffer = (f.getName() + String.valueOf(f.length())).getBytes("UTF-8");
            ins.close();
            md5.update(buffer, 0, buffer.length);
        }
        return DigestUtils.md5Hex(md5.digest());
    }

    /**
     * 单个文件的MD5
     * @param fileName 文件的绝对路径
     * @return 快速MD5结果
     * @throws IOException 文件不存在异常
     * @throws NoSuchAlgorithmException 计算MD5异常
     */
    public static String genQuickMd5(String fileName) throws IOException, NoSuchAlgorithmException{
        File f = new File(fileName);
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        InputStream ins = new FileInputStream(f);
        byte[] buffer = (f.getName() + String.valueOf(f.length())).getBytes("UTF-8");
        ins.close();
        md5.update(buffer, 0, buffer.length);

        return DigestUtils.md5Hex(md5.digest());
    }

    /**
     * 通用 MD5 加密
     * @param str 计算源
     * @return 标准MD5结果
     */
    public static String genStandardMD5Str(String str) {
        MessageDigest messageDigest;

        try {
            messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.reset();
            messageDigest.update(str.getBytes("UTF-8"));
        } catch (NoSuchAlgorithmException e) {
            logger.error("NoSuchAlgorithmException caught!", e);
            return null;
        } catch (UnsupportedEncodingException e) {
            logger.error(e.getMessage(), e);
            return null;
        }

        byte[] byteArray = messageDigest.digest();

        StringBuilder md5StrBuff = new StringBuilder();

        for (byte aByteArray : byteArray) {
            if (Integer.toHexString(0xFF & aByteArray).length() == 1)
                md5StrBuff.append("0").append(Integer.toHexString(0xFF & aByteArray));
            else
                md5StrBuff.append(Integer.toHexString(0xFF & aByteArray));
        }

        return md5StrBuff.toString();
    }
}