package com.gupao.uploader.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gupao.framework.anotation.RequestLimit;
import com.gupao.uploader.model.User;
import com.gupao.uploader.constant.Constants;
import com.gupao.uploader.util.FastJsonUtil;
import com.gupao.uploader.util.Md5Util;
import com.gupao.uploader.api.ApiIface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@Component
@RestController
@RequestMapping("/web/user")
@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "SpringJavaAutowiringInspection"})
public class UserAuth {

    private static Logger logger = LoggerFactory.getLogger(UserAuth.class);
    @Value("#{general.batch_uploader_key}")
    private String batchUploaderKey;

    @Autowired
    private ApiIface apiIface;

    /**
     * 通用管理平台用户权限对接API
     */
    private static final String restApi = "content/getBatchUploadParams";

    @RequestLimit
    @RequestMapping(value = "/validateToken", method = {RequestMethod.POST}, produces = Constants.PRODUCES_UTF8)
    public String login(HttpServletRequest request,
                        @RequestParam(name = "job", required = false) String job,
                        @RequestParam(name = "sign", required = false) String sign,
                        @RequestParam(name = "ipAddr", required = false) String ipAddr) {

        // 本地用户任意登录
        User user = apiIface.localLogin();
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute(job, user);

            JSONObject result = new JSONObject();
            result.put("job", job);
            JSONObject userData = (JSONObject) JSON.toJSON(user);
            result.putAll(userData);
            logger.info("成功登录。。");
            return FastJsonUtil.success("成功登录！", result).toJSONString();
        }

        if (job == null || sign == null || ipAddr == null) {
            return FastJsonUtil.error(400, "参数不正确!").toString();
        }

        logger.info("开始验证签名...: " + job + "\t" + sign + "\t" + ipAddr);
        String calSign = Md5Util.genStandardMD5Str(job + batchUploaderKey);
        if (calSign == null) {
            return FastJsonUtil.error(-4, "未能正常计算签名").toJSONString();
        }
        if (!calSign.equals(sign)) {
            return FastJsonUtil.error(-3, "签名不正确").toJSONString();
        }
        logger.info("验证计算正确!");
        Map<String, String> params = new HashMap<>();
        params.put("token", job);

        logger.info("对接系统的签名是否有效...");
        JSONObject response = apiIface.sendData(restApi, params);
        if (response == null) {
            return FastJsonUtil.error(-4, "token失效或者对接系统有问题").toJSONString();
        }
        logger.info("对接系统的签名有效!");
        JSONObject data = response.getJSONObject("data");
        Integer projectId = data.getInteger("projectID");
        String projectName = data.getString("projectName");
        Integer sectionId = data.getInteger("sectionID");
        String sectionName = data.getString("sectionName");
        Integer userId = data.getInteger("userID");
        String userName = data.getString("userName");

        user = new User()
                .setProjectID(projectId)
                .setProjectName(projectName)
                .setSectionID(sectionId)
                .setSectionName(sectionName)
                .setUserID(userId)
                .setUserName(userName)
                .setIpAddr(ipAddr.startsWith("http://") ? ipAddr : "http://" + ipAddr);

        HttpSession session = request.getSession();
        session.setAttribute(job, user);

        JSONObject result = new JSONObject();
        result.put("job", job);
        JSONObject userData = (JSONObject) JSON.toJSON(user);
        result.putAll(userData);
        logger.info("成功登录。。");
        return FastJsonUtil.success("成功登录！", result).toJSONString();
    }

    @RequestMapping(value = "/logout", produces = Constants.PRODUCES_UTF8)
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return FastJsonUtil.success("成功退出").toJSONString();
    }
}
