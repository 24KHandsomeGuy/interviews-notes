package com.gupao.uploader.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.gupao.uploader.util.FileUtil;

/**
 * 处理进度bean
 *
 * @author mark
 */
public class ProcessBean implements Serializable {

    public static class PreData {
        private String sortKey;
        private String api;

        public String getSortKey() {
            return sortKey;
        }

        public void setSortKey(String sortKey) {
            this.sortKey = sortKey;
        }

        public String getApi() {
            return api;
        }

        public void setApi(String api) {
            this.api = api;
        }

        public JSONObject getData() {
            return data;
        }

        public void setData(JSONObject data) {
            this.data = data;
        }

        private JSONObject data;

        public PreData(String sortKey, String api, JSONObject data) {
            this.sortKey = sortKey;
            this.api = api;
            this.data = data;
        }
    }

    /**
     * 处理进度查询bean
     * @author mark
     *
     */
    public static class Result {
        /**
         * 处理理论综述
         */
        public int total = Integer.MAX_VALUE;

        /**
         * 实际处理数量
         */
        public int actual = total;

        /**
         * 处理成功总数
         */
        public int success = 0;

        /**
         * 处理过程是否有异常产生
         */
        public boolean exceptionStatus = Boolean.FALSE;

        /**
         * 处理异常消息
         */
        public String exceptionMsg;

        /**
         * 已处理完成总数（进度条使用）
         */
        public int processed = 0;

        /**
         * 错误消息列表
         */
        public final List<String> errMsgs = new ArrayList<>();

        /**
         * 待发送数据的列表集合(JSONObject)
         */
        public List<PreData> preDatas = new ArrayList<>();

        /**
         * 生成错误日志
         * @param token 进度查询token
         * @param dir 日志保存dir
         * @return 生成的日志绝对路径
         */
        public String writeLog(String token, String dir) {
            if (errMsgs.isEmpty()) {
                return null;
            }
            FileUtil.createLocalFolder(dir);
            File file = new File(dir, token + ".log");
            if (file.exists()) {
                return file.getAbsolutePath();
            }
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(file);
                for (int i = 0; i < errMsgs.size(); i++) {
                    String msg = errMsgs.get(i);
                    fos.write((String.valueOf(i)+"\t").getBytes("UTF-8"));
                    fos.write(msg.getBytes("UTF-8"));
                    fos.write("\r\n".getBytes("UTF-8"));
                }
            } catch (Exception e) {  
                e.printStackTrace();  
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return file.getAbsolutePath();
        }
    }

    private final Result result = new Result();

    /**
     * 标题目录
     */
    private String titleDir;

    /**
     * 缺省序列化
     */
    private static final long serialVersionUID = 1L;
    /**
     * 文件名
     */
    private String fileName;
    /**
     * 章节Id
     */
    private String sectionId;
    /**
     * 标题
     */
    private String title;
    /**
     * 类型code（dramaSeries，videos，video，book，album）
     */
    private String code;

    private String topDir;

    /**
     * book dir
     */
    private String strBookDir;

    public String getStrBookDir() {
        return strBookDir;
    }

    public void setStrBookDir(String strBookDir) {
        this.strBookDir = strBookDir;
    }

    public String getCsvNodeRoot() {
        return csvNodeRoot;
    }

    public void setCsvNodeRoot(String csvNodeRoot) {
        this.csvNodeRoot = csvNodeRoot;
    }

    /**
     * 节点名称
     */
    private String csvNodeRoot;
    /**
     * userId
     */
    private String userId;

    /**
     * 项目ID
     */
    private String projectId;

    /**
     * 文件大小
     */
    private Long size;

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }
    /**
     * @return the sectionId
     */
    public String getSectionId() {
        return sectionId;
    }
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
    /**
     * @return the size
     */
    public Long getSize() {
        return size;
    }
    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    /**
     * @param sectionId the sectionId to set
     */
    public void setSectionId(String sectionId) {
        this.sectionId = sectionId;
    }
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
    /**
     * @param size the size to set
     */
    public void setSize(Long size) {
        this.size = size;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the projectId
     */
    public String getProjectId() {
        return projectId;
    }
    /**
     * @param projectId the projectId to set
     */
    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }
    /**
     * @return the topDir
     */
    public String getTopDir() {
        return topDir;
    }
    /**
     * @param topDir the topDir to set
     */
    public void setTopDir(String topDir) {
        this.topDir = topDir;
    }
    /**
     * @return the titleDir
     */
    public String getTitleDir() {
        return titleDir;
    }
    /**
     * @param titleDir the titleDir to set
     */
    public void setTitleDir(String titleDir) {
        this.titleDir = titleDir;
    }
    /**
     * @return the result
     */
    public Result getResult() {
        return result;
    }

}
