package com.gupao.uploader.constant;

/**
 * @author Mark
 *
 */
public final class Constants {

    public static final String PRODUCES_UTF8 = "application/json;charset=UTF-8";
    
    public static final String API_SUCCESS_CODE = "J000000";
}
