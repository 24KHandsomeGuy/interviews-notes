/*
 * jQuery File Upload Validation Plugin
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2013, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */

/* global define, require, window */

;(function (factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        // Register as an anonymous AMD module:
        define([
            'jquery',
            './jquery.fileupload-process'
        ], factory);
    } else if (typeof exports === 'object') {
        // Node/CommonJS:
        factory(require('jquery'));
    } else {
        // Browser globals:
        factory(
            window.jQuery
        );
    }
}(function ($) {
    'use strict';

    // Append to the default processQueue:
    $.blueimp.fileupload.prototype.options.processQueue.push(
        {
            action: 'validate',
            // Always trigger this action,
            // even if the previous action was rejected:
            always: true,
            // Options taken from the global options map:
            acceptFileTypes: '@',

            fileTypeBook: '@',
            fileTypePhoneBook: '@',
            fileTypeVideo: '@',
            fileDramaSeries: '@',

            maxFileSize: '@',
            minFileSize: '@',
            maxNumberOfFiles: '@',
            disabled: '@disableValidation'
        }
    );

    // The File Upload Validation plugin extends the fileupload widget
    // with file validation functionality:
    $.widget('blueimp.fileupload', $.blueimp.fileupload, {

        options: {
        	fileTypeBook: /(\.|\/)(csv|zip)$/i,
        	fileTypePhoneBook: /(\.|\/)(csv|jpe?g|png)$/i,
        	fileTypeVideo: /(\.|\/)(mp4)$/i,
        	fileDramaSeries: /(\.|\/)(mp4)$/i,

            // The regular expression for allowed file types, matches
            // against either file type or file name:
            //acceptFileTypes: /(\.|\/)(jpe?g)$/i,
        	acceptFileTypes: /(\.|\/)(mp4|csv|zip|jpg|png)$/i,
            // The maximum allowed file size in bytes:
            //maxFileSize: 2097152000, // 20 MB
            // The minimum allowed file size in bytes:
            // minFileSize: undefined, // No minimal file size
            // The limit of files to be uploaded:
            maxNumberOfFiles: 1000,

            // Function returning the current number of files,
            // has to be overriden for maxNumberOfFiles validation:
            getNumberOfFiles: $.noop,

            // Error and info messages:
            messages: {
                maxNumberOfFiles: 'Maximum number of files exceeded',
                acceptFileTypes: 'File type not allowed',
                maxFileSize: 'File is too large',
                minFileSize: 'File is too small'
            }
        },

        processActions: {

            validate: function (data, options) {
                if (options.disabled) {
                    return data;
                }
                var dfd = $.Deferred(),
                    settings = this.options,
                    file = data.files[data.index],
                    fileSize;
                if (options.minFileSize || options.maxFileSize) {
                    fileSize = file.size;
                }
                var code=$('input:radio:checked').val();
                if ($.type(options.maxNumberOfFiles) === 'number' &&
                        (settings.getNumberOfFiles() || 0) + data.files.length >
                            options.maxNumberOfFiles) {
                    file.error = settings.i18n('maxNumberOfFiles');

                } else if (options.acceptFileTypes &&
                        !(options.acceptFileTypes.test(file.type) || options.acceptFileTypes.test(file.name))) {
                    file.error = settings.i18n('acceptFileTypes');

                } else if (fileSize > options.maxFileSize) {
                    file.error = settings.i18n('maxFileSize');
                } else if ($.type(fileSize) === 'number' &&
                        fileSize < options.minFileSize) {
                    file.error = settings.i18n('minFileSize');
                } else if (code =='book' && !(options.fileTypeBook.test(file.type) || options.fileTypeBook.test(file.name))
                    	|| code =='phoneBook' && !(options.fileTypePhoneBook.test(file.type) || options.fileTypePhoneBook.test(file.name))
                    	|| code =='video'&& !(options.fileTypeVideo.test(file.type) || options.fileTypeVideo.test(file.name))
                    	|| code =='dramaSeries'&& !(options.fileDramaSeries.test(file.type) || options.fileDramaSeries.test(file.name))) {
                	file.error = settings.i18n('acceptFileTypes');
                 } else {
                    delete file.error;
                }

//                String msg = "error";
//                if (envProperty.codeBook.equals(code)) {
//                    if (fileName.matches(".*\\.(csv|zip)")) {
//                        msg = "";
//                    }
//                } else if (envProperty.codePhoneBook.equals(code)) {
//                    if (fileName.matches(".*\\.(csv|jpe?g|png)")) {
//                        msg = "";
//                    }
//                } else if (envProperty.codeDramaSeries.equals(code)) {
//                    if (fileName.matches(".*\\.(mp4)")) {
//                        msg = "";
//                    }
//                } else if (envProperty.codeVideo.equals(code)) {
//                    if (fileName.matches(".*\\.(mp4)")) {
//                        msg = "";
//                    }
//                }

               
                

                if (file.error || data.files.error) {
                    data.files.error = true;
                    dfd.rejectWith(this, [data]);
                } else {
                    dfd.resolveWith(this, [data]);
                }
                return dfd.promise();
            }

        }

    });

}));
