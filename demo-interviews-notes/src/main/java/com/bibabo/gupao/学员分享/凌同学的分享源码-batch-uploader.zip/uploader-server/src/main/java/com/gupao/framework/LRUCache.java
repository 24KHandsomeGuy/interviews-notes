package com.gupao.framework;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author mark
 *
 * @param <K>
 * @param <V>
 */
public class LRUCache<K, V> extends LinkedHashMap<K, V>{
    private static final long serialVersionUID = -1882071901467368406L;
    private static final int DEFAULT_INITIAL_CAPACITY = 16;
    private static final float DEFAULT_LOAD_FACTOR = 0.75f;
    private static final int DEFAULT_CACHE_SIZE = 1024;

    private final int cacheSize;

    public LRUCache() {
        this(DEFAULT_INITIAL_CAPACITY, DEFAULT_LOAD_FACTOR, DEFAULT_CACHE_SIZE);
    }

    public LRUCache(int capacity, float loadFactor, int cacheSize) {
        super(capacity, loadFactor, true);
        this.cacheSize = cacheSize;
    }

    /*
     * (non-Javadoc)
     * @see java.util.LinkedHashMap#removeEldestEntry(java.util.Map.Entry)
     */
    @Override
    protected boolean removeEldestEntry(Map.Entry<K,V> eldest) {
        return size() > cacheSize;
    }
}
