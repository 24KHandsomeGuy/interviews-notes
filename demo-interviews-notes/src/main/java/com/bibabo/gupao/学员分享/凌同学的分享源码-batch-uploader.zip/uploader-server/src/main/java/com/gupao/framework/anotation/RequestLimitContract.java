package com.gupao.framework.anotation;

import com.gupao.framework.LRUCache;
import com.gupao.uploader.util.HttpRequestUtil;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

@Aspect
@Component
public class RequestLimitContract {
    private static final Logger logger = LoggerFactory.getLogger(RequestLimitContract.class);

    /**
     * ip#url -> 时间列表
     */
    private static final LRUCache<String, ConcurrentLinkedQueue<Long>> limitAccessTime =
            new LRUCache<>(16, 0.75f, 1024);

    /**
     * 被封的IP地址
     */
    private static final LRUCache<String, Long> forbiddenIpAddrs =
            new LRUCache<>(16, 0.75f, 10240);

    /**
     * key是否受限
     * @param key ip#url
     * @param forbiddenPeriod 受限时间
     * @return true受限，false不受限
     */
    private boolean isForbidden(String key, long forbiddenPeriod) {
        Long forbiddenTime = forbiddenIpAddrs.get(key);
        if (forbiddenTime == null) {
            return false;
        }
        if (System.currentTimeMillis() < forbiddenTime + forbiddenPeriod) {
            return true;
        }
        forbiddenIpAddrs.remove(key);
        return false;
    }

    @Before("@annotation(limit)")
    public void requestLimit(JoinPoint joinPoint, RequestLimit limit) throws Exception {
        String key = getKey(joinPoint);
        if (isForbidden(key, limit.period())) {
            return;
        }
        // 时间
        Long now = System.currentTimeMillis();
        Long before = now - limit.time();

        ConcurrentLinkedQueue<Long> queue = limitAccessTime.get(key);
        int count = 1;
        if (queue != null) {
            Iterator<Long> itr = queue.iterator();
            while (itr.hasNext()) {
                long accessTime = itr.next();
                if (accessTime < before) {
                    itr.remove();
                } else {
                    count++;
                }
            }
        } else {
            queue = new ConcurrentLinkedQueue<>();
        }
        if (count > limit.count()) {
            logger.info(key+ " 超过了次数限制" + limit.count());
            throw new RequestLimitException();
        }
        queue.add(now);
        limitAccessTime.put(key, queue);
    }

    /**
     * 访问key（ip#url）
     * @param joinPoint 切入点
     * @return key
     * @throws RequestLimitException 访问限制
     * @throws IOException ip获取产生异常
     */
    private String getKey(JoinPoint joinPoint) throws RequestLimitException, IOException {
        Object[] args = joinPoint.getArgs();
        HttpServletRequest request = null;
        for (Object arg : args) {
            if (arg instanceof HttpServletRequest) {
                request = (HttpServletRequest) arg;
                break;
            }
        }
        if (request == null) {
            throw new RequestLimitException("方法中缺失HttpServletRequest参数");
        }

        // key
        String ip = HttpRequestUtil.getIpAddress(request);
        String url = request.getRequestURL().toString();
        logger.info("用户IP[" + ip + "]访问地址[" + url);
        return ip + "#" + url;
    }
}