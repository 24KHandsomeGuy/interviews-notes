package com.gupao.framework;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;

@SuppressWarnings("SpringAutowiredFieldsWarningInspection")
@Component("jsonConfig")
public class JsonConfig {

    @Value("#{general.json_config_dir}")
    private String jsonConfigDir;

    @Autowired
    private ServiceFactory serviceFactory;

    public JSONObject read(String projectId) throws Exception {
        File file = new File(jsonConfigDir, projectId+".JSON");
        String text = FileUtils.readFileToString(file);
        return JSON.parseObject(text);
    }

    /**
     * 获取已被注册的ProcHandler
     * @param config JSON配置根节点
     * @param nodeRoot 待处理类型的根节点。如book,phoneBook等.
     * @param <T> 返回的ProcBean类型
     * @return ProcBean实例
     */
    @SuppressWarnings("unchecked")
    public <T> T getProcHandler(JSONObject config, String nodeRoot) {
        // 获取project根
        JSONObject project = config.getJSONObject("project");

        // 获取procHandler集合
        JSONObject procHandlers = project.getJSONObject("procHandlers");

        // 得到相应的处理器
        String procHandler = procHandlers.getString(nodeRoot);

        // 获得该处理器的实例
        return (T)serviceFactory.buildService(procHandler);
    }

    /**
     * 获取已被注册的ProcHandler
     * @param projectId 项目Id
     * @param csvNodeRoot root节点
     * @param <T> 返回的ProcBean类型
     * @return ProcBean实例
     */
    @SuppressWarnings("unchecked")
    public <T> T getProcHandler(String projectId, String csvNodeRoot) throws Exception {
        JSONObject project = read(projectId);
        return getProcHandler(project, csvNodeRoot);
    }
}
