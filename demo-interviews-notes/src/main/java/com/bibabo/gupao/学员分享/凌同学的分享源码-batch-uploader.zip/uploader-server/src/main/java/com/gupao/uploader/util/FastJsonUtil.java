package com.gupao.uploader.util;

import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * JSON结果工具
 *
 * @author Mark
 *
 */
public final class FastJsonUtil {

    private static Logger logger = LoggerFactory.getLogger(FastJsonUtil.class);

    public static JSONObject error(Integer code, String msg) {
        JSONObject json = newInstance(code, msg, null);
        logger.error(msg);
        return json;
    }

    public static JSONObject success(String msg, Object data) {
        return newInstance(0, msg, data);
    }
    public static JSONObject success(String msg) {
        return newInstance(0, msg, null);
    }
    public static JSONObject success() {
        return newInstance(0, "success", null);
    }

    private static JSONObject newInstance(Integer code, String msg, Object data) {
        JSONObject result = new JSONObject();
        result.put("code", code);
        result.put("msg", msg);
        result.put("data", data);
        return result;
    }
}
