package com.gupao.uploader.filter;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gupao.framework.AuthenticatedUserHolder;
import com.gupao.uploader.model.User;
import com.gupao.uploader.constant.Constants;
import com.gupao.uploader.util.FastJsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LoginFilter
 */
@WebFilter("/LoginFilter")
public class LoginFilter implements Filter {
    private static final Logger logger = LoggerFactory.getLogger(LoginFilter.class);
    private static Pattern[] patterns;

    /**
     * 无需登录就可以访问的URI
     */
    private static final Set<String> skipComponents = new HashSet<>();

    /**
     * 登录用Uri不进行拦截
     */
    static {
        skipComponents.addAll(Collections.singletonList("/uploader-server/web/user/"));
    }

    /**
     * @see Filter#destroy()
     */
    @Override
    public void destroy() {
    }

    /**
     * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
     */
    @Override
    public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain chain)
            throws IOException, ServletException {

        if (arg0 instanceof HttpServletRequest && arg1 instanceof HttpServletResponse ) {
            HttpServletRequest request = (HttpServletRequest) arg0;
            HttpServletResponse response = (HttpServletResponse) arg1;
            String uri = request.getRequestURI();
            logger.info(uri);
            if (patterns != null) {
                for (Pattern pattern : patterns) {
                    if (pattern.matcher(uri).matches()) {
                        logger.debug("Avoid permission check for: {}", uri);
                        chain.doFilter(arg0, arg1);
                        return;
                    }
                }
            }
            if (checkSkipUris(uri)) {
                chain.doFilter(request, response);
                return;
            }

            HttpSession session = request.getSession(false);

            if (session == null) {
                // 跳转到登录页
                response.setHeader("Content-type", Constants.PRODUCES_UTF8);
                OutputStream ps = response.getOutputStream();
                // utf8格式
                ps.write(FastJsonUtil.error(-1, "未登录，禁止访问").toJSONString().getBytes("UTF-8"));
                return;
            } else {
                // job
                String job = request.getParameter("job");
                // 获取session会话内容保存到本地线程
                if (job != null) {
                    logger.debug("filter : job=" + job);
                    User user = (User) session.getAttribute(job);
                    AuthenticatedUserHolder.set(user);
                }
            }
        }
        // pass the request along the filter chain
        chain.doFilter(arg0, arg1);
    }

    /**
     * @see Filter#init(FilterConfig)
     */
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        String exclusionPattern = filterConfig.getInitParameter("EXCLUSIONS");
        if (exclusionPattern == null) {
            return;
        }
        String[] patternStrings = exclusionPattern.split(",");
        patterns = new Pattern[patternStrings.length];
        for (int i = 0; i < patternStrings.length; ++i) {
            patternStrings[i] = patternStrings[i].trim();
            patternStrings[i] = patternStrings[i].replace("*", "(.*)").replace("?", "(.{1})");
            patterns[i] = Pattern.compile(patternStrings[i].trim(), Pattern.CASE_INSENSITIVE);
        }
    }
    private static boolean checkSkipUris(String uri) {
        for (String url : skipComponents) {
            if (uri.startsWith(url)) {
                return true;
            }
        }
        return false;
    }

}
