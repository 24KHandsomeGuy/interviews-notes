package com.gupao.uploader.util;

import java.io.*;
import java.nio.charset.UnmappableCharacterException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.gupao.uploader.constant.EnvProperty;

/**
 *
 * 文件上传工具类（单例模式）
 * @author mark
 *
 */
@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "SpringJavaAutowiringInspection"})
public class FileUtil {

    private static final int BUFFER_SIZE = 1024;
    private static final Logger logger = LoggerFactory.getLogger(FileUtil.class);

    @Autowired
    private EnvProperty envProperty;

    private static final ExecutorService fixedThreadPool = Executors.newFixedThreadPool(30);

    public static String cutPath(String path) {
        int index = path.indexOf("/web/capitalLibrary/");
        if (index >= 0) {
            return path.substring(index+"/web".length());
        }
        return path;
    }

    /**
     *
     * @param file 写入的文件
     * @param bytes 字节数组
     * @param totalSize 文件总大小
     * @param seekIndex 写入的偏移量
     */
    public static void write(File file, byte[] bytes, long totalSize, long seekIndex) {
        RandomAccessFile randomFile = null;
        try {
            // 打开一个随机访问文件流，按读写方式
            randomFile = new RandomAccessFile(file, "rw");
            // 文件长度，字节数
            long fileLength = randomFile.length();
            if (fileLength < totalSize) {
                randomFile.seek(seekIndex);
                randomFile.write(bytes);
            }
        } catch (IOException e) {
            logger.error("写出错", e);
        } finally {
            if (randomFile != null) {
                try {
                    randomFile.close();
                } catch (IOException e) {
                    logger.error("关闭文件出错", e);
                }
            }
        }
    }

    /**
     * 创建文件夹
     * @param folder 文件夹绝对地址
     * @return 是否创建成功
     */
    public static boolean createLocalFolder(String folder) {
        String[] folders = folder.split("/", folder.length());
        StringBuilder sb = new StringBuilder("/");
        for (int i = 0; i < folders.length; i++) {
            if (folders[i].length() == 0) {
                continue;
            }
            sb.append(folders[i]).append("/");
            File file = new File(sb.toString());
            if (!file.exists()) {
                if (!file.mkdir()) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 根据视频生成相应的缩略图
     * @param absolutePathMp4 视频的绝对地址
     * @return 处理是否成功
     */
    public boolean processThumb(String absolutePathMp4) {

        String jpg = "\""+ FileUtil.replace(absolutePathMp4, ".mp4", ".jpg")+"\"";
        String size = "540x350 ";
        //        String ffmpeg = "/usr/local/bin/ffmpeg";
        byte[] bytes = null;
        String command = null;
        try {
            bytes = new StringBuilder(envProperty.ffmpeg)
                    .append(" -ss 120.000 -i ")
                    .append("\""+absolutePathMp4+"\"")
                    .append(" -y -f image2 -t 0.001 -s ")
                    .append(size)
                    .append(jpg).toString().getBytes("UTF-8");
            command = new String(bytes,"utf-8");
        } catch (UnsupportedEncodingException e) {
            logger.error("不支持的UTF-8类型", e);
            return false;
        }

        String[] cmds = {"/bin/sh","-c", command};
        Process pro;
        try {
            pro = Runtime.getRuntime().exec(cmds);
            printMessage(pro.getInputStream());
            printMessage(pro.getErrorStream());
            pro.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("mpeg 处理发生异常", e);
            return false;
        }
        return true;
    }

    private static void printMessage(final InputStream input) {
        fixedThreadPool.execute(() -> {
            Reader reader = new InputStreamReader(input);
            BufferedReader bf = new BufferedReader(reader);
            try {
                while(bf.readLine()!=null);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * 解压zip文件支持（UTF-8格式以及GBK格式）
     * @param zipFilePath zip文件绝对路径
     * @param saveFileDir 解压后的路径(Dir)
     * @return 解压结果参照：FastJsonUtil
     */
    public JSONObject decompressZip(String zipFilePath, String saveFileDir) {

        // 创建文件夹
        createLocalFolder(saveFileDir);

        int count = -1;
        InputStream is = null;

        FileOutputStream fos = null;

        String pngPath = null;
        Set<String> dirSet = new HashSet<>();

        ZipFile zipFile = null;
        try {
            try {
                // 尝试以uft-8字符集解压
                zipFile = new ZipFile(new File(zipFilePath), "utf-8");
            } catch (UnmappableCharacterException uce) {
                // 尝试以gbk字符集解压
                zipFile = new ZipFile(new File(zipFilePath), "gbk");
            }

            Enumeration<?> entries = zipFile.getEntries();

            while (entries.hasMoreElements()) {
                ZipEntry entry = (ZipEntry)entries.nextElement();
                String entryName = entry.getName();

                // 如果是文件夹则跳过
                if (entry.isDirectory()){
                    continue;
                }
                // 获取文件名
                if (entryName.toUpperCase().startsWith("__MACOSX")) {
                    continue;
                }
                if (entryName.matches("(.*/|)\\..*")) {
                    continue;
                }
                // entryFileName = getFileNmInZip(entryFileName);
                if (entryName.matches(".*\\.(jpe?g|png)")) {
                    int index = entryName.lastIndexOf("/");
                    if (index >= 0) {
                        pngPath = entryName.substring(0, index);
                        dirSet.add(pngPath);
                    }
                }
                // 构造解压出来的文件存放路径
                String entryFilePath = saveFileDir + entryName;
                byte[] content = new byte[BUFFER_SIZE];

                try {
                    is = zipFile.getInputStream(entry);
                    int dirIndex = entryFilePath.lastIndexOf("/");
                    if (dirIndex > 0) {
                        String dir = entryFilePath.substring(0, dirIndex);
                        createLocalFolder(dir);
                    }
                    File entryFile = new File(entryFilePath);
                    fos = new FileOutputStream(entryFile);
                    while ((count = is.read(content, 0 , BUFFER_SIZE)) != -1) {
                        fos.write(content, 0, count);
                    }
                } catch(IOException e) {
                    e.printStackTrace();
                    JSONObject result = new JSONObject();
                    result.put("code", "-1");
                    result.put("msg", e.getMessage());
                    result.put("data", "{}");
                    return result;
                } finally {
                    if(fos != null) {
                        fos.flush();
                        fos.close();
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            if (zipFile != null) {
                try {
                    zipFile.close();
                } catch (IOException e) {
                    logger.error("关闭zip文件异常", e);
                }
            }
        }
        return FastJsonUtil.success("OK", dirSet);
    }

    /**
     * 替换工具类（仅尝试替换最左侧或者最右侧字符串）
     * @param str 待替换的字符串
     * @param oldStr 需要被替换的旧字符串
     * @param newStr 需要替换成的新字符串
     * @param right 是否从左侧开始(null,true都是从右侧侧计算)
     * @return 处理的字符串
     */
    public static String replace(String str, String oldStr, String newStr, Boolean right) {
        if (str == null) {
            return null;
        }
        if (right == null || right) {
            if (str.indexOf(oldStr) == str.length() - oldStr.length()) {
                return str.substring(0, str.length() - oldStr.length()) + newStr;
            }
        } else {
            if (str.indexOf(oldStr) == 0) {
                return newStr + str.substring(oldStr.length());
            }
        }
        return str;
    }
    /**
     * 替换工具类（仅尝试替换最左侧或者最右侧字符串）
     * @param str 待替换的字符串
     * @param oldStr 需要被替换的旧字符串
     * @param newStr 需要替换成的新字符串
     * @return 处理的字符串
     */
    public static String replace(String str, String oldStr, String newStr) {
        return replace(str, oldStr, newStr, Boolean.TRUE);
    }
}

