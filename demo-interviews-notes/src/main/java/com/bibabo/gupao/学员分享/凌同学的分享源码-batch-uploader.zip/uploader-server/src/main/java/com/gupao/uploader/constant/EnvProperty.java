package com.gupao.uploader.constant;

import org.springframework.beans.factory.annotation.Value;

/**
 * 通用配置属性
 * @author mark
 *
 */
public class EnvProperty {
    /**
     * envTopdir
     */
    @Value("#{general.envTopdir}")
    public String envTopdir;
    /**
     * batchUpload
     */
    @Value("#{general.batch_upload}")
    public String batchUpload;

    /**
     * 临时存放路径（zip,csv）
     */
    @Value("#{general.tmp}")
    public String tmp;

    @Value("#{general.book}")
    public String book;

    @Value("#{general.phoneBook}")
    public String phoneBook;

    @Value("#{general.video}")
    public String video;

    @Value("#{general.ffmpeg}")
    public String ffmpeg;
    /**
     * 此变量为前后端约束值，必须保持一致。
     */
    @Value("#{general.chunk_size}")
    public Integer CHUNK_SIZE;

    /**
     * 上传图片后需要回显的静态资源访问域名
     */
    @Value("#{general.accessDomain}")
    public String accessDomain;

    /**
     * 删除时，使用的访问域名
     */
    @Value("#{general.domain}")
    public String domain;

    /**
     * 对接系统API的域名地址
     */
    @Value("#{general.gehua_system_api_domain}")
    public String gehuaSystemApiDomain;

//    .setProjectID(envProperty.mockProjectId)
//                .setProjectName(projectName)
//                .setSectionID(sectionId)
//                .setSectionName(sectionName)
//                .setUserID(userId)
//                .setUserName(userName)
//                .setIpAddr(ipAddr.startsWith("http://") ? ipAddr : "http://" + ipAddr);


    /**
     * 此变量为前后端约束值，必须保持一致。
     */
    @Value("#{general.dummy_projectId}")
    public Integer dummyProjectId;

    /**
     * 此变量为前后端约束值，必须保持一致。
     */
    @Value("#{general.dummy_sectionId}")
    public Integer dummySectionId;

    public final String codePhoneBook = "phoneBook";
    public final String codeDramaSeries = "dramaSeries";
    public final String codeVideos = "videos";
    public final String codeVideo = "video";
    public final String codeBook = "book";

}
