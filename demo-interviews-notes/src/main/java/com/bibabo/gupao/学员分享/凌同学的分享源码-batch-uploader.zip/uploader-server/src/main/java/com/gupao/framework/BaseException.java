package com.gupao.framework;

public class BaseException extends RuntimeException {
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    /**
     * 错误消息
     */
    public BaseException() {
        this("业务异常");
    }

    /**
     * 错误消息
     */
    public BaseException(String msg, Object... args) {
        super(String.format(msg, args));
    }
}
