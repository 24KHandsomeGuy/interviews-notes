package com.gupao.uploader.util;

import java.io.File;

import com.gupao.framework.AuthenticatedUserHolder;
import com.gupao.uploader.model.User;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gupao.uploader.model.MultipartFileParam;

/**
 *
 * 文件上传工具类
 * @author mark
 *
 */
public class ChunkUtil {

    /**
     * 保存chunk
     * @param params 文件上传参数
     * @return 保存是否成功
     */
    public boolean saveChunk(MultipartFileParam params) {
        //  long seekIndex, long fileSize, String dir, String fileName, byte[] bytes

        String dir = params.getDir();
        String fileName = params.getFileName();
        byte[] bytes = params.getBytes();

        long seekIndex = params.getSeekIndex();
        long chunkEndIndex = params.getChunkEndIndex();
        long totalSize = params.getFileSize();

        // 保证存储目录存在
        FileUtil.createLocalFolder(dir);

        // 存放路径：dir+文件名
        File file = new File(dir, fileName);

        FileUtil.write(file, bytes, totalSize, seekIndex);

        return totalSize <= chunkEndIndex + 1;
    }

    /**
     * 生成回显结果
     * @param fileName 文件名
     * @param fileSize 文件大小
     * @param dir 文件dir
     * @return 回显json
     */
    public JSONObject result(String fileName, long fileSize, String dir) {

        JSONObject result = new JSONObject();
        JSONArray files = new JSONArray();
        JSONObject file = new JSONObject();

        file.put("name", fileName);
        file.put("size", fileSize);
        String uriDir = "/web"+ FileUtil.cutPath(dir);

        User user = (User)AuthenticatedUserHolder.get();
        String accessDomain = user.getIpAddr();

        String url = encode(accessDomain, uriDir + fileName);
        file.put("url", url);

        if (fileName.matches(".*\\.(jpe?g|png)")) {
            file.put("thumbnailUrl", url);
        } else if (fileName.matches(".*\\.(mp4)")) {
            String jpg = encode(accessDomain,
                    uriDir + fileName.substring(0, fileName.length()-3) + "jpg");
            file.put("thumbnailUrl",  jpg);
            file.put("url", jpg);
            file.put("video", url);
        }

        files.add(file);
        result.put("files", files);
        return result;
    }

    private static String encode(String base, String source) {
        return base + source;
    }
}
