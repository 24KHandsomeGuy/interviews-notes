These are the Java-level sources for the Serviceability Agent (SA).

To build, type "gnumake all".

For usage documentation, please refer to ../doc/index.html.
