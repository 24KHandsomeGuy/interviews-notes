var config =function (){
	return {
		evnFlag: 'DEV',   //OL  线上     TEST 测试     DEV  开发
		url_root: 'http://localhost:8080',
        ip_address:'localhost:8080'
	}
}();
// 外网地址-测试地址(此处配置可以完成本地和线上等多环境前端配置)
if(location.host.indexOf('your-domain-extern-system')==0) {
	config.url_root = 'http://domain:8081';
	config.evnFlag = 'TEST';
    config.ip_address = "domain2";

    // 本地环境
} else {
	config.url_root = 'http://localhost:8080';
	config.evnFlag = 'DEV';
    config.ip_address = "http://localhost:8080";
}