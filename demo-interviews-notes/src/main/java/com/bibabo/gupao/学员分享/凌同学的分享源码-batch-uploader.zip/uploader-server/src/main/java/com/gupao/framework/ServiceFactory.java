package com.gupao.framework;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component("serviceFactory")
public class ServiceFactory implements ApplicationContextAware {

    /**
     * Spring上下文
     */
    private ApplicationContext applicationContext;

    @SuppressWarnings("unchecked")
    public <T> T buildService(String beanName) {
        return (T) applicationContext.getBean(beanName);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
