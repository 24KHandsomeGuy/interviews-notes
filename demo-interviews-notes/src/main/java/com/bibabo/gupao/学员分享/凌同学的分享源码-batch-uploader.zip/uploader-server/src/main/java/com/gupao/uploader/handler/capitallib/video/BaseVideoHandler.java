package com.gupao.uploader.handler.capitallib.video;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.gupao.framework.JsonConfig;
import com.gupao.framework.UploadProcessHolder;
import com.gupao.uploader.handler.base.BaseHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.gupao.uploader.constant.EnvProperty;
import com.gupao.uploader.model.ProcessBean;
import com.gupao.uploader.util.FileUtil;
import com.gupao.uploader.api.ApiIface;

/**
 * 视频相关基类
 * @author mark
 *
 */
@SuppressWarnings({"SpringAutowiredFieldsWarningInspection", "WeakerAccess"})
public abstract class BaseVideoHandler extends BaseHandler {

    private static final Logger logger = LoggerFactory.getLogger(BaseVideoHandler.class);
    @Autowired
    protected FileUtil fileUtil;

    @Autowired
    protected ApiIface apiIface;

    @Autowired
    protected EnvProperty envProperty;

    /**
     * 配置类
     */
    @Autowired
    protected JsonConfig jsonConfig;

    /**
     * 视频预处理
     * @param processBean 预处理结果Bean
     */
    protected abstract void preProcessTitle(ProcessBean processBean);

    /**
     * 构建结果Bean
     * @param projectId 项目ID
     * @param sectionId 章节ID
     * @param userId 用户ID
     * @param title 标题
     * @return 结果Bean
     */
    public abstract ProcessBean buildProcessBean(String projectId, String sectionId, String userId, String title);

    /**
     * 视频类异步处理
     *  @param params Map参数<br/>
     * ------------------------<br/>
     * projectId 项目Id
     * token 生成的查询token
     * userId 用户ID
     * csvNodeName procHandler的节点
     * sectionId 章节ID
     * title 标题
     */
    @Override
    public void asyncProcess(Map<String, Object> params) throws Exception {

        String projectId = getParam(params, "projectId");
        String sectionId = getParam(params, "sectionId");
        String userId = getParam(params, "userId");

        String title = getParam(params, "title");
        String token = getParam(params, "token");
        String code = getParam(params, "code");

        BaseVideoHandler baseVideoHandler = jsonConfig.getProcHandler(projectId, code);

        final ProcessBean processBean = baseVideoHandler.buildProcessBean(projectId, sectionId, userId, title);
        UploadProcessHolder.holder().put(token, processBean);
        fixedThreadPool.execute(()-> {
            try {
                baseVideoHandler.process(processBean);
            } catch (Exception e) {
                logger.error("处理过程产生异常", e);

                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);
                e.printStackTrace(pw);
                processBean.getResult().exceptionMsg = sw.toString();
                processBean.getResult().exceptionStatus = true;
            }
        });
    }

    /**
     * 预处理一个标题
     * @param processBean 结果查询bean
     */
    private void preProcessTitles(ProcessBean processBean) {

        String strCodeDir = envProperty.video +
                processBean.getSectionId() +
                "/" +
                processBean.getCode() +
                "/";
        strCodeDir = String.format(strCodeDir, processBean.getProjectId());

        File codeDir = new File(strCodeDir);
        if (!codeDir.exists() || !codeDir.isDirectory()) {
            logger.debug(String.format("文件夹为空或者不存在：%s", codeDir));
            return;
        }

        // 视频
        if (envProperty.codeVideo.equals(processBean.getCode())) {
                preProcessTitle(processBean);

            // 剧集和视频集
        } else {
            File[] titlesDir = codeDir.listFiles(File::isDirectory);

            // 文件夹
            if (titlesDir != null ) {
                for (File fileTitle : titlesDir) {
                    String title = processBean.getTitle();
                    // 获取文件夹名称作为title
                    processBean.setTitle(fileTitle.getName());
                    // 处理一个title剧集
                    preProcessTitle(processBean);
                    processBean.setTitle(title);
                }
            }
        }
    }

    /**
     * 预处理一个章节
     * @param processBean 结果查询bean
     */
    private void preProcessSection(ProcessBean processBean) {

        // 指定标题
        if (processBean.getTitle() != null) {
            preProcessTitle(processBean);

            // 未指定标题
        } else {
            preProcessTitles(processBean);
        }
    }

    /**
     * 预处理主业务逻辑
     * @param processBean 结果查询bean
     */
    private void preProcess(ProcessBean processBean) {

        // 章节ID
        String sectionId = processBean.getSectionId();

        // 全量处理
        if ("all".equals(sectionId)) {
            File file = new File(String.format(envProperty.video, processBean.getProjectId()));
            File[] sections = file.listFiles();
            for (File section : sections != null ? sections : new File[0]) {
                // 通过文件夹获取文章Id
                String originSectionId = processBean.getSectionId();
                processBean.setSectionId(section.getName());

                // 处理一章
                preProcessSection(processBean);
                processBean.setSectionId(originSectionId);
            }

            // 指定章节处理
        } else {
            preProcessSection(processBean);
         }
    }

    /**
     * 保存单条预处理结果
     * @param sortKey 排序用的Key
     * @param api 管理平台接口对接的API
     * @param data 对接的接口数据
     * @param result 预处理结果保存
     */
    protected void savePreProcessData(String sortKey, String api, JSONObject data, ProcessBean.Result result) {
        result.preDatas.add(new ProcessBean.PreData(sortKey, api, data));
    }

    /**
     * 处理主业务逻辑
     * @param processBean 结果查询bean
     */
    public void process(ProcessBean processBean) {

        // 预处理视频内容
        preProcess(processBean);

        // 获取预处理信息
        ProcessBean.Result result = processBean.getResult();
        List<ProcessBean.PreData> preDatas = result.preDatas;

        // 对预处理信息进行排序
        sortPreData(preDatas);

        // 更新总数
        result.total = preDatas.size();
        result.actual = preDatas.size();
        result.processed = 0;
        result.success = 0;

//        // 顺序结果
//        for (int i = 0; i < preDatas.size(); i++) {
//            ProcessBean.PreData preData = preDatas.get(i);
//            System.out.println((i+1)+"\t"+ preData.getSortKey());
//        }

        // 由于显示顺序是按照时间的倒叙，所以发送数据的顺序和预期看到的顺序是相反的。
        for (int i = preDatas.size() -1; i >= 0; i--) {
            ProcessBean.PreData preData = preDatas.get(i);
            String errMsg = apiIface.sendData(preData.getApi(), preData.getData().toJSONString());
            if (errMsg == null) {
                result.success++;
            } else {
                result.errMsgs.add(errMsg + "\t" + "content/saveVideos\t" + preData.getData().toJSONString());
            }
            result.processed++;
        }

        logger.info(String.format("正常处理：%s, 总数：%s", result.success, result.actual));
    }

    /**
     * 缺省的排序实现,子类可以覆盖该方法
     * @param preDatas 待发送数据集
     */
    protected void sortPreData(List<ProcessBean.PreData> preDatas) {
        preDatas.sort((ProcessBean.PreData a, ProcessBean.PreData b)
                -> (a.getSortKey().compareTo(b.getSortKey())));
    }

}
