package com.gupao.uploader.api;

import com.alibaba.fastjson.JSONObject;
import com.gupao.uploader.model.User;

import java.util.Map;

public interface ApiIface {
    String sendData(String api, String params);

    JSONObject sendData(String api, Map<String, String> data);

    User localLogin();
}